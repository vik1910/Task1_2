<?php  //go to prev. page
          session_start();
//echo "=============������� ����� - ".date("H:i:s");		   
echo "= "." ";		 
		   //changing language
           include 'language.php';
	
	       // ���������� ������
           include 'config.php';
		   
		   # include my php-lib
           include 'site_php_library.php';
		   
           $current_page = $_SESSION['current_page'];
//echo '0 $current_page = '.$current_page;		   
		   $all_pages = $_SESSION['all_pages'];
//echo '   1 $all_pages = '.$all_pages;		   
		   if($current_page < 2) 
		   {
		       $current_page = 2;
		   }//if
		   $prev_page = $current_page - 1;
		   $_SESSION['current_page'] = $prev_page;
	       echo 
		   '
		     		<div id="articles_content1">
					</div>
           ';   
	       echo '<div id="articles_content2">';
           $rab = table_articles();//List of Articles
	       echo '</div>';
?>