<?php
// Add_Record.php - �������� ��������� ������ ������ � �� � ������� ������ 

	session_start();
		
	# Load my library
    include 'my_library.php';
	
    # ���������� ������
    include 'config.php';
	
	// set language
	$lan = $_SESSION['lan'];

	// login of activ user
	$login = $_SESSION['login'];
	
	// id current theme
	$Theme_name_answer =$_SESSION["Theme_name_answer"];
	
//echo 'Theme_name_answer	='+Theme_name_answer;
	// set DB
	$dbname = $_SESSION['dbname'];
	$link = $_SESSION['link'];

	// get new theme using post
    $str = iconv("UTF-8", "Windows-1251", $_POST['name_Record']);
//echo '$str = '.$str;	
	// Get name_Theme2 and n_section
	if (!trim_2_param($str,$name_Record2,$n_section))
	{echo "name_Theme is't correct!";}
//echo '$n_section = '.$n_section;
	switch ($n_section) {
    case '1':
        $file_Theme = 'Theme_Rules';
		$lan_Forum_Rules_header_lan = $lan["Forum_Rules_header_lan"];		
		$file_answer = 'Theme_Rules';
        break;
    case '2':
        $file_Theme = 'Theme_manufacturer';
		$lan_Forum_Rules_header_lan = $lan["Forum_Manufacturer_on_line_header"];
		$file_answer = 'Theme_manuf';
    case '3':
        $file_Theme = 'Conferences';
		$lan_Forum_Rules_header_lan = $lan["Forum_Conference_hall"];
		$file_answer = 'Conferences';		
        break;
    case '4':
        $file_Theme = 'Ta_Database';
		$lan_Forum_Rules_header_lan = $lan["Forum_Tanks_Database"];
		$file_answer = 'Ta_Database';		
        break;
    case '5':
        $file_Theme = 'Tan_Reviews';
		$lan_Forum_Rules_header_lan = $lan["Forum_Tanks_owners"];
		$file_answer = 'Tan_Reviews';		
        break;	
    case '6':
        $file_Theme = 'Tr_Database';
		$lan_Forum_Rules_header_lan = $lan["Forum_Tractors_Database"];
		$file_answer = 'Tr_Database';		
        break;	
    case '7':
        $file_Theme = 'Tra_Reviews';
		$lan_Forum_Rules_header_lan = $lan["Forum_Tractors_owners"];
		$file_answer = 'Tra_Reviews';		
        break;	
    case '8':
        $file_Theme = 'Shoppingdoc';
		$lan_Forum_Rules_header_lan = $lan["Forum_Shopping_doc"];
		$file_answer = 'Shoppingdoc';		
        break;	
    case '9':
        $file_Theme = 'Shopping_3D';
		$lan_Forum_Rules_header_lan = $lan["Forum_Shopping_3D"];
		$file_answer = 'Shopping_3D';		
        break;			
    }  //  switch	
	$Theme_name_answer  = $file_answer . '_' . $Theme_name_answer;
//echo '$Theme_name_answer='.$Theme_name_answer;	
	
	$theme_user_login=mysql_real_escape_string($_SESSION['login']);	// login user of theme

	// Write new Theme in DB
	if (strlen($name_Record2) > 0)
	{
	  // id author Theme
	  $Theme_users_id2 = $_SESSION['users_id'];
	  
	  // reading name of file curent answer
//	  $Theme_name_answer = search_records('Theme_Rules', 'Theme_id', $id_current_theme, 'Theme_name_answer', $dbname); 
// echo '$Theme_name_answer='.$Theme_name_answer;
	  // Data and Time of creating Theme
	  $Theme_data2 = (string)date("Y.m.d");
	  $Theme_time2 = (string)date("H:i"); //(����� ����� ��������� � �������: 13:45) 
	  
	  // Writing in table  Theme_Rules
	  
	  $query="INSERT INTO ". $Theme_name_answer . 
           " (Theme_Rules_Theme_id,Theme_Rules_x_user_id,Theme_Rules_text,Theme_Rules_data,Theme_Rules_time) 
           VALUES ('$id_current_theme','$Theme_users_id2','$name_Record2','$Theme_data2','$Theme_time2')";	
// echo '$query='.$query.'\n ';
	  $add_Theme = mysql_query($query, $link); 

	  // Reading answers from table $name_answer3 and writing in HTML
      $tablename = $Theme_name_answer;
// echo '$tablename='.$tablename.'    ';	  
      if (mysql_table_seek($tablename, $dbname))
	  {
	    if ($link)
	    {			
	      $query = "SELECT * FROM " . $tablename;
		  $result = mysql_query($query ) or die("Invalid query: " . mysql_error());
// echo '$result='.$result.'  ';		  
	    }	// if	 
	  
	    $sch = 0; // number records in table tablename
        while ($row2 = mysql_fetch_array($result, MYSQL_BOTH)) 
	    {   
 	      $sch = $sch + 1;

	      // reading id from table tablename
		  $Theme_Rules_x_user_id = $row2['Theme_Rules_x_user_id'];
	  
		  // reading login author of theme
		  $users_login_author_theme = search_records('users', 'users_id', $Theme_Rules_x_user_id, 'users_login', $dbname);
		  
		  // reading name of Theme
		  $name_theme = Time_To_UKR(search_records($file_Theme, 'Theme_id', $row2['Theme_Rules_Theme_id'], 'Theme_text', $dbname));
				
		  // reading login author of answer
		  $users_login_author_answer = search_records('users', 'users_id', $row2['Theme_Rules_x_user_id'], 'users_login', $dbname);

		  // reading data, time of theme
		  $data_theme = search_records($file_Theme, 'Theme_id', $row2['Theme_Rules_Theme_id'], 'Theme_data', $dbname);
		  $time_theme = search_records($file_Theme, 'Theme_id', $row2['Theme_Rules_Theme_id'], 'Theme_time', $dbname);

		  // reading data, time of answer
		  $data_answer = Time_To_UKR($row2['Theme_Rules_data']);	
		  $time_answer=$row2['Theme_Rules_time'];
		
		  // reading  answer
		  $text_answer = $row2['Theme_Rules_text'];	
		
		  // writing in HTML	
		  $lan_Add_Record=$lan["Add_Record"];	

		  // for first records
		  if ($sch == 1)
		  {
		    $str3 = '<div id="rab0404">
				<style> #rab0404 {background: #696969;
						  color: white;
				}</style>
			  &nbsp;'.$lan["Theme"].':&nbsp;
			  '.$text_answer.'
			  &emsp;&emsp;'.$lan["Author"].':&nbsp;'
			  .$users_login_author_theme.'&emsp;&emsp;
			  '.$lan["Date"].':&nbsp;'.$data_answer.'
		    </div></br>
					  <div id="forma_Record">

			<div id="forma_Record_txt">
				'.$lan_Enter_new_Record.':* <br/>
			</div>		
			<div id="name_Record">			
			  <textarea id="name_Record2" name="name_Record3"
			       cols="120" rows="5" wrap="off" autofocus></textarea><br>
			</div>	
			<div id="button_record1_txt">
			   *'.$lan_Enter_new_Record600.'
			</div>			
			<div id="button_record_rules1">
			    <input  id="button" type="button" name="OK_Record" value="OK" onClick="OK_Add_Record('.$n_section.')" /><br/>
		    </div>	  	
		  </div> 	
			';	  
		    echo  $str3;	
		    $_SESSION["id_current_theme"]=$row2['Theme_Rules_Theme_id'];
		  }  // if
		  else
		  {
            $str1 = '<div id="rab0604"> 
		             <style> #rab0604 {
						  color: #d8860b;;
				     }</style>
				     &nbsp;'.$lan["Record_from"].':&emsp; 
			         '.$users_login_author_answer.'&emsp;&emsp;
				     '.$data_answer.'&emsp;&emsp;
				     '.$time_answer.'&emsp;</br>
				   </div>
					 <hr width="500"  color="#696969" align="left" size="2" />
		             &emsp;'.$text_answer.'
					 <hr width="1000"  color="#696969" align="left" size="2" />';
			  
            echo  $str1;
          }		
        }  //while  
	    $str2 = '<spacer  width="500"></spacer>
			   <div id="button_Add_Record">
			     <input  id="#button_Add_Record2" type="button" name="Add_Record" value="'.$lan_Add_Record.'" onClick="Add_Record()" />
		       </div>					   		   
			   ';
	    echo  $str2;
		$lan_back_record=$lan["Back_Record"];
		$str3 = '<spacer  width="10"></spacer>
			   <div id="button_back_record">
			     <input  id="#button_back_record2" type="button" name="back_record" value="'.$lan_back_record.'" onClick="Back_Record('.$n_section.')" />
		       </div>					   		   
			   ';
	    echo  $str3;
	  }  //if
	  else echo 'Not exist table ' . $name_theme_answer;
	}  //if
?>