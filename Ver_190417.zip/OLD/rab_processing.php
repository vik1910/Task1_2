<?php
$namef2 = 'flag_reg.txt';
$err[0] = "inp";
$kod_flag = 5;
if (isset($err)) 
{
		# óñòàíîâêà ôëàãà = 1,...,9	- åñòü îøèáêè
		if (!file_exists($namef2)) echo "File flag_reg.txt not exist 1";
		else
        {
			$fp = fopen($namef2, "a"); // Îòêðûâàåì ôàéë â ðåæèìå çàïèñè 
			ftruncate($fp, 0); // î÷èùàåì ôàéë
			$test = fwrite($fp, $kod_flag); // Çàïèñü â ôàéë
			if (!$test) echo 'Error write to flag_reg.txt.';
			fclose($fp); //Çàêðûòèå ôàéëà
		}
}

include ('rab.php'); 

?>