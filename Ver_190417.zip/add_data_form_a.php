<?php  //Save form for new editing
	session_start();
// echo '==============';
//$file = 'Debugging.txt';
//$current = file_get_contents($file);
	global $lang, $lan,  $autor_registr;
	
	//changing language
    include 'language.php';
	
	# ���������� ������
    include 'config.php';
	
	# include my php-lib
    include 'site_php_library.php';
	
	$lan_not_Name_Article = $lan["not_Name_Article"];
	
	$ar_new_tags = array();
	$k = 0;
	for ($i = 0; $i < count($_SESSION['ar_tags']); $i++)
	{
	  if($_SESSION['ar_tags'][$i] != '')
	  {
	    $ar_new_tags[$k] = $_SESSION['ar_tags'][$i];
	
		$k++;	
	  }//if
	}//for


	//Check data form
	$php_Name_article = $_GET['p_Name_article'];
	$rab = stripWhitespaces($php_Name_article);	
//$current .= '   4:  $string3 = '.$php_Name_article;
//file_put_contents($file, $current);	
	$rab = htmlspecialchars($php_Name_article);
//$current .= '   2:  $php_Name_article = '.$php_Name_article;
//file_put_contents($file, $current);		
	$p_content_form_article = $_GET['p_text_form_article'];
	$p_button_URL_adress = '';
	$p_button_URL_adress =  $_GET['p_button_URL_adress'];
//echo '$php_Name_article = '.$php_Name_article;
	//check URL_adress
	$p_button_URL_adress = trim($p_button_URL_adress);
	if($p_button_URL_adress != '')
	{
	  $p_button_URL_adress = htmlspecialchars($p_button_URL_adress);
	}//if
	$login_user = $_SESSION['login_user'];
	$flag_form = false;
	$flag2 = false;
	$flag3 = false;
	$p_tags_form_article = array();
	if($p_button_URL_adress != '') //there is URL_adress 
	{	  
        //name of Article from site
		$php_Name_article = Name_Article_URL_adress($p_button_URL_adress);
	    $php_Name_article = htmlspecialchars($php_Name_article);

		//content from site
		$p_content_form_article = Content_Article_URL_adress($p_button_URL_adress);
//echo '===$content_URL_adress = '.$content_URL_adress;		
		if($p_content_form_article != '')
		{
//echo '$p_content_form_article = '.$p_content_form_article;
		    $p_content_form_article = trim($p_content_form_article);
	        $p_content_form_article = htmlspecialchars($p_content_form_article);

		//array of tags from site
            $p_tags_form_article = Tags_Article_URL_adress($php_Name_article);
			$flag_form = true;
		}//if
		else //there is error: site was not found
		{
		    $flag_form = false;
			echo '
	               <div id="messages_err">
		              <br/>
                      <img src="img/error.png" align="left">
		              <p align="center"><font color="red">'.$lan["not_site"].'<br/>
		              '.$lan["Press_OK_to_continue"].'</font></p><br/><br/>
                      <div id="button_ok">
				        <input  id="button_ok2" type="button"  align="middle" name="ok_reg" value="OK" onClick="ok_err_no_name_a()" />
                      </div>
                   </div><br>
	             ';
		}//else
	}//if
	else //no any URL-adress
	{
	    if($php_Name_article == '') //no any name of Article
	    {
	        echo '
	              <div id="messages_err">
		              <br/>
                      <img src="img/error.png" align="left">
		              <p align="center"><font color="red">'.$lan_not_Name_Article.'<br/>
		              '.$lan["Press_OK_to_continue"].'</font></p><br/><br/>
                      <div id="button_ok">
				        <input  id="button_ok2" type="button"  align="middle" name="ok_reg" value="OK" onClick="ok_err_no_name_a()" />
                      </div>
                 </div><br>
	           ';
	    }//if
	    else //there is name of Article
	    {
	        $p_content_form_article = trim($p_content_form_article);
	        $p_content_form_article = htmlspecialchars($p_content_form_article);
//$current .= '   3:  $php_Name_article = '.$php_Name_article;
//file_put_contents($file, $current);				
			//check - is there name in DB ?
			$query = mysql_query("SELECT COUNT(article_id) FROM articles_table WHERE 
				   article_name='".mysql_real_escape_string($php_Name_article)."'")
				   or die ("<br>Invalid query: " . mysql_error()); 
                 if(mysql_result($query, 0) != 0) //there is  this name in DB
                 { // 
				   echo 
				   '
	                 <div id="messages_err">
		                <br/>
                        <img src="img/error.png" align="left">
		                <p align="center"><font color="red">'.$lan["there_is_this_name_Article"].'<br/>
		                  '.$lan["Press_OK_to_continue"].'</font>
						</p><br/><br/>
                        <div id="button_ok">
				            <input  id="button_ok2" type="button"  align="middle" name="ok_reg" value="OK" onClick="ok_err_no_content_a()" />
                        </div>
                     </div><br>
	               ';
				   $flag_name = false;
				 }//if
				 else $flag_name = true;
	        if($p_content_form_article == '') // no content of the Article
	        {//no content of Article
	          echo '
	                <div id="messages_err">
		                <br/>
                        <img src="img/error.png" align="left">
		                <p align="center"><font color="red">'.$lan["not_Content_Article"].'<br/>
		                  '.$lan["Press_OK_to_continue"].'</font>
						</p><br/><br/>
                        <div id="button_ok">
				            <input  id="button_ok2" type="button"  align="middle" name="ok_reg" value="OK" onClick="ok_err_no_content_a()" />
                        </div>
                    </div><br>;
	             ';
	        }//if
	        else //There are Name and Content of new Article
	        {   
	            $flag_form = true;
				//form array of tags
				$k = 0;
	            for ($i = 0; $i < count($_SESSION['ar_tags']); $i++)
	            {
	                if($_SESSION['ar_tags'][$i] != '')
	                {
	                    $p_tags_form_article[$k] = $_SESSION['ar_tags'][$i];
		                $k++;
	                }//if
	            }//for
	        }//else
	    }//else
	}//else
	if($flag_form and $flag_name)//there are all data in form - write into DB
	{
 		 //adding new tags
		 if(count($p_tags_form_article) > 0)//there are new tags
		 {
		     for ($i = 0; $i < count($p_tags_form_article); $i++)
	         {
			     $new_tag = $p_tags_form_article[$i];
				 $new_tag = stripWhitespaces($new_tag);
		         $query = mysql_query("SELECT COUNT(tag_id) FROM tags_table WHERE 
				   tag_name='".mysql_real_escape_string($new_tag)."'")
				   or die ("<br>Invalid query: " . mysql_error()); 
                 if(mysql_result($query, 0) == 0) //there is not this tag in DB
                 { // add new tag into tags_table
				    $new_tag = stripWhitespaces($new_tag);
					if($new_tag != '')
					{
				        $add_tag = mysql_query("INSERT INTO `tags_table`  (tag_name) VALUES ('".mysql_real_escape_string($new_tag)."')");
                        if(@mysql_error($dbname)!='') 
			            {die("Error in DB!");}
			            else {$flag2 = true;}
					}//if
		         }//if
		     }//for
		 }//if
		 //adding new Article
         $data_reg2 = date("d.m.Y");
         $time_reg2 = date("H:i:s"); //format is: 13:45:32)
		 $php_Name_article = stripWhitespaces($php_Name_article);
         $query = mysql_query("SELECT COUNT(article_id) FROM articles_table 
		                       WHERE article_name='".mysql_real_escape_string($php_Name_article)."'")
                  or die ("<br>Invalid query: " . mysql_error()); 
		 if(mysql_result($query, 0) == 0) //there is not this name in DB
         { // 
		     $php_Name_article = stripWhitespaces($php_Name_article);
			 $p_content_form_article = stripWhitespaces($p_content_form_article);
			 $p_button_URL_adress = stripWhitespaces($p_button_URL_adress);
			 $data_reg2 = stripWhitespaces($data_reg2);
			 $time_reg2 = stripWhitespaces($time_reg2);
			 $login_user= stripWhitespaces($login_user);
			 $php_Name_article = stripWhitespaces($php_Name_article); 
			 if($php_Name_article != '')
			 {
                    $add_tag = mysql_query("INSERT INTO articles_table  
			             (article_name, article_content, article_URL, article_data, article_time, users_login) 
						 VALUES ('".mysql_real_escape_string($php_Name_article)."', '".mysql_real_escape_string($p_content_form_article)."', 
						 '".mysql_real_escape_string($p_button_URL_adress)."','".mysql_real_escape_string($data_reg2)."', 
						 '".mysql_real_escape_string($time_reg2)."', '".mysql_real_escape_string($login_user)."')");
                    if(@mysql_error($dbname)!='') 
			        {die("Error in DB!");}
			        else {$flag3 = true;}
			 }//if
		 }//if 
		 //creating articles_tags_table
		 if(flag2 and flag3) //there are writing into DB for tags_table and articles_table
		 {
		     for ($i = 0; $i < count($p_tags_form_article); $i++)
	         {		
                 $php_Name_article = mysql_real_escape_string($php_Name_article);

				 $query = "SELECT article_id  FROM articles_table WHERE article_name ="."'".$php_Name_article."'"."  LIMIT 1";
                 $data = mysql_fetch_assoc(mysql_query($query)); 
				 $data_article_id = $data["article_id"];
				 $data_article_id = stripWhitespaces($data_article_id);
//$current .= '   1:  $data_article_id = '.$data_article_id;
//file_put_contents($file, $current);
				 $new_tag = $p_tags_form_article[$i];
				 $new_tag = stripWhitespaces($new_tag);
				 $new_tag = mysql_real_escape_string($new_tag);
			 
				 $query = "SELECT tag_id FROM tags_table WHERE tag_name = "."'".$new_tag."'"."  LIMIT 1";
                 $data = mysql_fetch_assoc(mysql_query($query)); 
                 $new_tag_id = $data['tag_id'];
//$current .= '   2:  $new_tag_id = '.$new_tag_id;
//file_put_contents($file, $current);
				 $new_tag_id= stripWhitespaces($new_tag_id);
                 if(($data_article_id != '') and ($new_tag_id != ''))
                 {				 
				    $new_tag_id = mysql_real_escape_string($new_tag_id);
					$data_article_id = mysql_real_escape_string($data_article_id);
		            $add_tag = mysql_query("INSERT INTO `articles_tags_table`
			                 (`article_id`, `tag_id`) 
							 VALUES ('".$data_article_id."', '".$new_tag_id."')");
                    if(@mysql_error($dbname)!='') 
			        {die("Error in DB!");}
				 }//if
			 }//for
			 $_SESSION['ar_tags'] = array();
		 }//if       
		 $result = mysql_query ("UPDATE articles_table");
		 $result = mysql_query ("UPDATE tags_table");
		 $result = mysql_query ("UPDATE articles_tags_table");
		 
		 //Hide Article form

		 
		 echo '
                  <style>
				      #forma_article{
                          display: none;
					  } 
					  #table1_articles{
                          display: block;
					  } 
				  </style>
		      ';
/**/		  
		//rewrite articles table
        echo 
		   '<div id="articles_content2">';
		   
               $rab = table_articles();//call articles table (second time)
		   
	       echo '
           </div>
		   ';   
		
//		echo 'rewrite_table_a();';
	}//if
	
	function Tags_Article_URL_adress($Name_Article) //read tags from Name of Article (without URL-adress)
	{
	  if($Name_Article != '')
	  {
	    $tags_array = array();
	    $tags_array = explode(" ", $Name_Article);
		$new_tags_array = array();
		//check unique of tegs
		for ($i = 0; $i < count($tags_array); $i++)
	    {
		  $query = mysql_query("SELECT COUNT(tag_id) FROM tags_table WHERE tag_name='".mysql_real_escape_string($tags_array[$i])."'")or die ("<br>Invalid query: " . mysql_error()); 
          if(mysql_result($query, 0) == 0) //there is not this tag in DB
          { 
		    $new_tag = $tags_array[$i];
            $new_tag = trim($new_tag);
            $new_tag = htmlspecialchars($new_tag);
            $new_tags_array[count($new_tags_array)] =  $new_tag;
          } 
		}//for
		return $new_tags_array;
      }//if
	  else return false;
	}//function Tags_Article_URL_adress
	
	function Name_Article_URL_adress($URLadress) //read Name from url-adress
	{
	  if($URLadress != '')
	  {
	      $pos_slash = strripos($URLadress, '/');
	      $Name_Article = '';
	      if($pos_slash > 0)
	      {
	           $Name_Article = substr($URLadress,$pos_slash,strlen($URLadress));
	      }//if
	      else
	      {
	          $Name_Article = $URLadress;
	      }//else
          return $Name_Article;
	  }//if
	  else
      {
  	      echo 'Error in function Name_Article_URL_adress';
		  return false;		
	  }//else	  
    }//function Name_Article_URL_adress
	
    function Content_Article_URL_adress($URLadress) //read content from url-adress
	{
	  $e='';
	  if($URLadress != '')
	  {
	    $content_URL_article1 = '';
		$exc = 1;
		if (!file_exists(urlencode($URLadress)))
		{
		   $content_URL_adress1 = '';
		}//if
		else
		{
		    $content_URL_adress1 = @file_get_contents(urlencode($URLadress));
		}//else
//echo '$content_URL_adress = '.$content_URL_adress;		
		if($content_URL_adress1 != '') 
		{
		    $len_URLadress = strlen($URLadress);
		     $content_URL_article2 = substr($content_URLadress1,$len_URLadress);
		     if($content_URL_article2 == '')
		     {
		          $content_URL_article2 = substr($content_URLadress1,0);
		     }//if
		     $content_URL_article1 = $content_URL_article2;
		}//if
//echo '+++++++$content_URL_adress1 = '.$content_URL_adress1;		
		return $content_URL_adress1;
	  }//if
	  else
      {
  	    echo 'Error in function Content_Article_URL_adress';
		return false;		
	  }//else
    }//function Content_Article_URL_adress

?>