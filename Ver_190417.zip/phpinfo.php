<?php
 echo date('d-m-y H:i:s');


phpinfo();
?>