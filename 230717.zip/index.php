<?php  // index.php - main contant of site SKV
	session_start();

	global $lang, $lan,  $autor_registr, $login_user, $ar_tags, 
	       $n_last_tag, $php_p, $max_rows_page, $current_page,
		   $all_pages;
	
	//changing language
    include 'language.php';
	
	# ���������� ������
    include 'config.php';
	
	$_SESSION['lan']=$lan;
    $lan = $_SESSION['lan'];
	
	//
	if (isset($_SESSION['autor_registr']))
	{$autor_registr='yes';}
	else { $autor_registr='no';}
	
	$ar_tags=array(); //array of tags
	$_SESSION['ar_tags'] = $ar_tags;
	$p_main = '1';
	
	$lan_Articles_and_Tags = $lan['Articles_and_Tags'];
	
	$flag = true;
	$i = 1;
	$par2 = '1';
	
	$php_p = $_SESSION['php_p'];
	
	$max_rows_page = 10;//max number of rows in first page of the table
	$_SESSION['max_rows_page'] = $max_rows_page;
	$_SESSION['current_page'] = 1;


?>
<!DOCTYPE html>
<html>
<head>
    <title><?php  echo $lan_Articles_and_Tags; ?></title>	
	<base http://www.my_syte.com>  <!--  -->
	<link rel="stylesheet" type="text/css"  href="css/main.css" />	
	<script type="text/javascript" src="js/jquery-3.2.0.min.js"></script> 
	<script type="text/javascript" src="js/jquery.complexify.js"></script> 
    <script type="text/javascript" src="js/site_js_library.js"></script>	
	<meta charset="windows-1251" />
	<meta http-equiv="DESCRIPTION" content="Articles and Tags">
	<meta http-equiv="KEYWORDS" content="article, tag">

</head>
 
<body onload="contant_main(&#34;<?php echo $p_main ?>&#34;)">
  
  <div class="wrapper">
        <div id="header_top">  
		   <center><h1><?php echo $lan["Catalog_of_Articles"] ?></h1></center>
		   <form action="forma_lang.php" method="post">		   
             <button type="submit" name="button_rus"><img id="head_flag_rus" src="img/rus.png" 
			         width="40" title="<?php echo $lan['Russian'] ?>" height="40" />
			 </button>
             <button type="submit" name="button_eng"><img id="head_flag_eng" src="img/eng.png" 
			         width="40" title="<?php echo $lan['English'] ?>" height="40" />
			 </button>        
		   </form> 			 
        </div> 
<!--		
        <div id="header_bottom">
		
            <SPAN id="main"> 
   				 <SPAN><style>#main {background: #d0c3b2;}</style></SPAN><?php echo $lan["Main"] ?>
			</SPAN>
			<SPAN id="tags"    onClick="forum('1')"><?php echo $lan["Tags"] ?></SPAN>
   		    <hr/>	
        </div>
 -->
        <div id="content_main1">		
	    </div>
		
		<div id="content_main">		   
	    </div>
       <div id="content_main11">		
	    </div>
		<div id="content_main2">
	    </div>
		
		<div id="content_main3" >		   
			     <form id="searchform" method="post"> 
                   <div> 
					  <input id="button_prev_page" type="button" name="name_prev_page" size="100" 
					         value=<?php echo $lan["prev_page"] ?>  />
					  <input id="button_next_page" type="button" name="name_next_page" size="100" 
					         value=<?php echo $lan["next_page"]?>  />
                      <SPAN id="many_pages"><?php echo $lan["Page"]?></SPAN> 
					  <SPAN id="select_page">
					        <?php
						        $str2 = '<form id="form_number_page" name="name_form_number_page"  method="post">
								         <select id="select_number_page" name="select_page" size="1" onChange="StatusSelect();">';
	                            for ($i = 1; $i <= $_SESSION['all_pages']; $i++)
	                            {
								     if($_SESSION['current_page'] == $i)
									    {$str2 = $str2.'<option selected value='.'"'.$i.'"'.'>'.$i.'</option>';}
									 else
	                                    {$str2 = $str2.'<option value='.'"'.$i.'"'.'>'.$i.'</option>';}
	                            }//for
	                            $str3 = '</select> </form>';
								echo $str2.$str3;
	                        ?>
					  </SPAN>
					  <input  id="button_article_search" type="button"  align="middle" name="ok_article_search" size="100" 
					         value=<?php echo $lan["Search"] ?> onClick="article_search()"/>
					  
					  <input  id="button_article_add" type="button"  align="middle" name="ok_article_add" size="100" 
					         value=<?php echo $lan["Add"] ?> onClick="article_add()"/>
					  <input id="read_page" type="button" name="name_read_page" size="100" 
					         value=<?php echo $lan["read_page"] ?> onclick="f_read_page()"  /> <!-- -->
					  <input  id="button_article_edit" type="button"  align="middle" name="ok_article_edit" size="100"
					         value=<?php echo $lan["Edit"] ?> onClick="article_edit()">
					  <input  id="button_article_del" type="button"  align="middle" name="ok_article_del" size="100"
          				     value=<?php echo $lan["Delete"] ?> onClick="article_del()">
                      <SPAN id="search_article">
						    <?php
	                            $query2 = mysql_query("SELECT  tag_name FROM `tags_table` ORDER BY tag_name");		
	                            $number_rows_tag = mysql_num_rows($query2);	
                                if($number_rows_tag > 0)//there are tags
                                {		
                                    $str2 = '<form id="form_search_article" name="name_form_search_article"  method="post">
                                             <select id="search_number_article" name="search_article" size=1 onChange="StatusSearch();">';
		                            for ($k = 0; $k < $number_rows_tag; $k++)
	                                {	
			                            $data2 = mysql_fetch_assoc($query2);
			                            $article_tag_name = $data2['tag_name'];
                                        $str2 = $str2.'<option  value='.$article_tag_name.'>'.$article_tag_name.'</option>';
		                            }//for
		                            echo $str2.'</select>';
	                            }//if
	                        ?>
				      </SPAN>							 

                   </div> 
                 </form> 	
	    </div>

 		<div id="menu_bottom">	
		</div>
        
        <div id="footer">
			<div id="copyright1">
				<center>Copyright &#169 - <?php echo $lan["Articles_and_Tags"] ?></center>
			</div>
			<div id="designer">
			</div>
        
        </div>
		
</div>

   <!--  -->   

</body>
</html>