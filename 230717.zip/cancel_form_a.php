<?php  //Save form for new editing
	session_start();
// echo '==============';
	global $lang, $lan,  $autor_registr;
	
	////changing language
    include 'language.php';
	
	# ���������� ������
    include 'config.php';
	
	# include my php-lib
    include 'site_php_library.php';
	
	 
		 echo '
                  <style>
				      #forma_article{
                          display: none;
					  } 
					  #table1_articles{
                          display: block;
					  } 
				  </style>
		      ';

        //rewrite articles table
        echo 
		   '<div id="articles_content2">';
		   
               $rab = table_articles();//call articles table (second time)
		   
	       echo '
           </div>
		   ';   

?>