<?php 
	session_start();
//echo '==============';
	
    //changing language
    include 'language.php';
	
	# ���������� ������
    include 'config.php';
	# include my php-lib
    include 'site_php_library.php';
$file = 'DEBUGGING.txt';
$current = file_get_contents($file);

	$number_rows_tag = array();
	$login_user = $_SESSION['login_user'];
$current .= '   1:  $login_user = '.$login_user;
file_put_contents($file, $current);		
	$query = "SELECT article_id  FROM articles_table WHERE users_login ="."'".$login_user."'";
	$data = mysql_query($query);
	while($data2 = mysql_fetch_assoc($data))
	{
	    $data_article_id = $data["article_id"];
$current .= '   1:  $data_article_id = '.$data_article_id;
file_put_contents($file, $current);	
	    $data_article_id = stripWhitespaces($data_article_id);
 	    $data_article_id = mysql_real_escape_string($data_article_id);
		$query2 = "SELECT tag_id  FROM articles_tags_table WHERE article_id ="."'".$data_article_id."'";
		$data3 = mysql_query($query2);
	
		while($data4 = mysql_fetch_assoc($data3))
	    {
		     $number_rows_tag[count($number_rows_tag)] = $data4["tag_id"];
$current .= '   1:  $number_rows_tag = '.$number_rows_tag[count($number_rows_tag)-1];
file_put_contents($file, $current);				 
		}//wile
	}//while
	$query2 = mysql_query("SELECT  tag_name FROM `tags_table` ORDER BY tag_name");		

	$number_rows_tag = mysql_num_rows($query2);	
//	echo '$number_rows_tag = '.$number_rows_tag;

    if($number_rows_tag > 0)//there are tags
    {		
        $str2 = '<form id="form_search_article" name="name_form_search_article"  method="post">
                 <select id="search_number_article" name="search_article" size="1" onChange="StatusSearch();">';
		for ($k = 0; $k < $number_rows_tag; $k++)
	    {
			$data2 = mysql_fetch_assoc($query2);
			$article_tag_name = $data2['tag_name'];
            $str2 = $str2.'<option  value='.$article_tag_name.'>'.$article_tag_name.'</option>';
		}//for
		echo $str2.'</select></form>';
	}//if
	
?>