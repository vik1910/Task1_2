<?php

	session_start();

	if (isset($_POST['button_eng']))
	{
	  $lang = 'eng';
	  $_SESSION['lang2']='eng';	
	}
	else
	{
	  $lang = 'rus';
	  $_SESSION['lang2']='rus';	
	}

	include 'index.php';
?>