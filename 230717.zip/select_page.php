<?php  //go to prev. page
          session_start();
//echo "=============������� ����� - ".date("H:i:s");		   
//echo "= "." ";		 
		   //changing language
           include 'language.php';
	
	       // ���������� ������
           include 'config.php';
		   
		   # include my php-lib
           include 'site_php_library.php';
//$file = 'DEBUGGING.txt';
//$current = file_get_contents($file);
	   
		   $_SESSION['current_page'] = strip_tags(substr($_POST['search_term'],0, 100));

           $current_page = $_SESSION['current_page'];
//$current .= '   111:  $current_page = '.$current_page;
//file_put_contents($file, $current);				   
//	       echo 
//		   '
//		     		<div id="articles_content1">
//					</div>
//           ';   
//	       echo '<div id="articles_content2">';
           $rab = table_articles();//List of Articles
//	       echo '</div>';
?>