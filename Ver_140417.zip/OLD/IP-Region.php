<?php
function occurrence($ip='', $to = 'utf-8'){
$ip = ($ip) ? $ip : $_SERVER['REMOTE_ADDR'] ;
$xml =  simplexml_load_file('http://ipgeobase.ru:7020/geo?ip='.$ip);
if($xml->ip->message)
{
	if( $to == 'utf-8' ) {return $xml->ip->message;} 
	else {
		if( function_exists( 'iconv' ) ) return iconv( "UTF-8", $to . "//IGNORE",$xml->ip->message);
		else return "The library iconv is not supported by your server";}
	} else { 
		if( $to == 'utf-8' ) {return $xml->ip->region;} 
		else {if( function_exists( 'iconv' ) ) return iconv( "UTF-8", $to . "//IGNORE",$xml->ip->region);
			else return "The library iconv is not supported by your server";}}}
echo occurrence('','utf-8');
?>


