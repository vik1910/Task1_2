<?php  // about_company.php - menu About_company site SKV
	session_start();
// echo '==============';
	global $lang, $lan,  $autor_registr;
	
	if (isset($_SESSION['lang2']))
	{
	  if ($_SESSION['lang2'] == 'eng')
	  {
			$lang = 'eng';
	  }
	  else
	  {
	  	    $lang = 'rus';
	  }
	}
	else
	{
		$lang = 'rus';
		$_SESSION['lang2']='rus';
	}

	if (!file_exists('txt/'.$lang.".ini")) echo "File 'txt/'.$lang.'.ini' not exist";
	else $lan = parse_ini_file('txt/'.$lang.".ini"); //��������� ��������������� �������� ���� 

	$_SESSION['lan']=$lan;
    $lan = $_SESSION['lan'];
	
	//�����  � �����-� �����-� � �������-� 
	if (isset($_SESSION['autor_registr']))
	{
	  $autor_registr='yes';
	}
	
	$lan_PRODUCT_CATALOGUE = $lan["PRODUCT_CATALOGUE"];
	$lan_Tractors = $lan["Tractors"];
	$lan_Tanks = $lan["Tanks"];
	$lan_self_propelled_vehicles = $lan["self-propelled_vehicles"];
	$lan_Product_Search = $lan["Product_Search"];
	$lan_Find = $lan['Find'];
	$lan_AUTHORIZATION = $lan["AUTHORIZATION"];
	$lan_Input = $lan['Input'];
	$lan_REGISTRATION = $lan["REGISTRATION"];
	$lan_Registration_Form = $lan["Registration_Form"];
	$lan_Enter_the_data = $lan["Enter_the_data"];
	$lan_Login = $lan["Login"];
	$lan_Password = $lan["Password"];
	$lan_Name = $lan["Name"];
	$lan_Surname = $lan["Surname"];
	$lan_obligatory_for_input = $lan["obligatory_for_input"];
	$lan_Username_can_only_consist = $lan["Username_can_only_consist"];
	$lan_Username_must_be_at_least = $lan["Username_must_be_at_least"];
	$lan_Send = $lan['Send'];
	$lan_OUR_LOCATION = $lan["OUR_LOCATION"];
	$lan_Our_Firm = $lan["Our_Firm"];
	$lan_Our_City = $lan["Our_City"];
	$lan_Our_street = $lan["Our_street"];
	$lan_Tel = $lan["Tel"];
	$lan_Please_go_to = $lan["Please_go_to"];
	$lan_Sign_in_or_Register = $lan["Sign_in_or_Register"];
	$lan_Press_OK_to_continue = $lan["Press_OK_to_continue"];
	
	$str1 = '
				<img  id="big_foto" src="img/gal_foto2.jpg" width="700" height="600" name="big_foto" />
				<img id="out" src="img/out.jpg" width="12" height="12" onClick="outPict()" />
			
			<div id="content_left">
 				<div id="kat_prod"><h1>'.$lan_PRODUCT_CATALOGUE.'</h1></div> 
				<div id="list_prod">
					<ul type="disk">
						<li><a href="trac.html">'.$lan_Tractors.'</a></li>
						<li><a href="tanc.html">'.$lan_Tanks.'</a></li>
						<li><a href="samoh.html">'.$lan_self_propelled_vehicles.'</a></li>
					</ul>
				</div>
				<div id="search_product">'.$lan_Product_Search.':
					
						<input type="text" name="serch1" size="24" maxlength="30" value="" />
						<div id="search_button">
							<input id="search_button2" type="button" name="start_serch1" size="100" value="'.$lan_Find.'" />
						</div>

					
					<div id="line_podch2">
					  <hr width="190"  color="#b3b3b3" align="left" size="2" />
				    </div>	
				</div>
				<div id="author"><h1>'.$lan_AUTHORIZATION.'</h1></div>
				<div id="authoriz1">
					
                        <div id="login1">
                            '.$lan_Login.':<br />
							<input id="login_auto" type="text" name="login_auto" size="25" maxlength="30"  />
						</div>
						<div id="password1">
							'.$lan_Password.':<br />				
							<input id="password_auto" type="password" name="password_auto" size="25" maxlength="30" />
						</div>	
						<div id="submit_button1">
							<input id="button_auto" type="button" name="input_author1" size="100" value="'.$lan_Input.'" onClick="in_autoriz()" />
							<br/>
						</div>				
						<br/>
				</div>	
				<div id="messages">
					<div id="load1_auto" style="display:none;"><img src="img/load.gif" />
					</div>
					<div id="answer_auto"> 
					</div>
					<div id="answer2_auto">
					</div>
					<div id="load1_check" style="display:none;"><img src="img/load.gif" />
					</div>
					<div id="answer_check"> 
					</div>
					<div id="answer2_check">
					</div>
                </div>	
				
                    <div id="line_podch1">
						<hr width="190"  color="#b3b3b3" align="left" size="2">
				    </div>
					<div id="registration1">
						<div  id="registration" onClick="visibl_form_reg()">'.$lan_REGISTRATION.'</div>
					</div>
                    <br/>
                    <div id="line_podch1">
					   <hr width="190"  color="#b3b3b3" align="left" size="2">
				    </div>
					<div id="form_registr">
            	        
						<div id="form_registr_zag" ><center>'.$lan_Registration_Form.'</center></div>
						<div id="form_registr_main">
							
                          	    <img id="out_messages" src="img/out.jpg" width="12" height="12" onClick="out_messages1()" />				
                                <table >
                                 <tr>
                                    <td  colspan="2" height="30" cellpadding="10" >'.$lan_Enter_the_data.':</td>
                                    <td ></td>
                                  </tr>
                                  <tr>
								    <td>'.$lan_Login.':*</td>
                                    <td><input id="login" type="text" size="20" maxlength="30"  name="login" onClick="form_login()"/></td>
                                  </tr>
                                  <tr>
                                	<td>'.$lan_Password.':*</td>
                                    <td><input id="password" type="password" size="20" maxlength="30" name="password"  onclick="form_password()" /></td>
                                  </tr>
                                  <tr>
								    <td>'.$lan_Name.':</td>
                                    <td><input id="first_name" type="text" size="20" name="first_name" /></td>
                                  </tr>
                                  <tr>
								    <td>'.$lan_Surname.':</td>
                                    <td><input id="last_name" type="text" size="20" name="last_name" /></td>
                                  </tr>
                                  
                                  <tr>
								    <td>Email:<br /></td>
                                    <td height="30"><input id="email" type="text" size="20" name="email" /></td>
                                  </tr>  
                                  <tr>
                                    <td  colspan="2" height="20">* - '.$lan_obligatory_for_input.'.</td>
                                    <td ></td>
                                  </tr>
								  <tr>
                                    <td  colspan="2" height="40">'.$lan_Username_can_only_consist.'<br/>
									                             '.$lan_Username_must_be_at_least.'<br/>
									</td>
                                    <td ></td>
                                  </tr>
								  <tr>
                                    <td></td>
                                    <td><pre>  </pre> </td>
                                  </tr>
                                  <tr>
                                    <td></td>
                                    <td height="30"><input id="button" type="button" name="b_form_reg" value="'.$lan_Send.'" onClick="out_form()" /></td>
                                  </tr>
                                  <tr>
                                    <td></td>
                                    <td><pre>  </pre> </td>
                                  </tr>
                                </table>
                                <div id="load1" style="display:none;"><img src="img/load.gif" />
								</div>
								<div id="answer"> 
								</div>
								<div id="answer2">
								</div>
                            
						</div>

					</div>
				
				<div id="our_coord"><h1>'.$lan_OUR_LOCATION.'</h1></div>
			
				<div id="adress">
					<center>'.$lan_Our_Firm.'</center>
					<p><center>61093, '.$lan_Our_City.',</center></p>
					<font face="Verdana"  color="#e8907e">
						<p><center>'.$lan_Our_street.', 111</center></p></br>
					</font> 
					<p><center>'.$lan_Tel.':<font face="Verdana"  color="#30a0c6">+38 050-333-22-55</font> </center></p>
					<p><center>E-mail: rab@mail.ru</center></p>
					
						<p><center><font face="Verdana"  color="#30a0c6">Skype:</font>  PetrovVI</center></p>
					
				</div>
			</div>
			<div id="forum_messages">				
					<div id="messages_err"> 
						<br/>
						<img src="img/error.png" align="left">
						<p align="center"><font color="red">'.$lan_Please_go_to.' <br/>
							'.$lan_Sign_in_or_Register.'<br/>
							'.$lan_Press_OK_to_continue.' </font></p><br/><br/>
						<div id="button_ok">
							<input  id="button_ok2" type="button"  align="middle" name="ok_forum" value="OK" onClick="out_forum_messages()" />
						</div>
					</div>
			</div>
			<div id="content_right">
					<a id="main_foto1" href="trac.html"><img  src="img/main_foto1.jpg" width="173" height="130" /></a>
					<a id="main_foto2" href="trac.html"><img  src="img/main_foto2.jpg" width="173" height="130" /></a>
					<a id="main_foto3" href="trac.html"><img  src="img/main_foto3.jpg" width="173" height="130" /></a>
					<div id="main_theme">
					�������� ����������� ������������ �������� ...
					</div>
					
			</div>
			<style>
			  #main {background: #dcdcdc;}
			  #catalog {background: #dcdcdc; }
			  #where_buy {background: #dcdcdc;}
			  #about_company {background: #dcdcdc;}			
			  #contacts {background: #d0c3b2;}				
			  #forum {background: #dcdcdc;}
			  #main2 {background: #dcdcdc;}
			  #catalog2 {background: #dcdcdc;}
			  #where_buy2 {background: #dcdcdc;}
			  #about_company2 {background: #dcdcdc;}			
			  #contacts2 {background: #d0c3b2;}				
			  #forum2 {background: #dcdcdc;}			  
		    </style>
		';	
	echo $str1;
?>			