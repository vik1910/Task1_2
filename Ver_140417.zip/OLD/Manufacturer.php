<?php
	//Manufacturer.php -  - section Manufacturer in Forum of site SKV

	session_start();

    $login = $_SESSION['login'];		
	
    # ���������� ������
    include 'config.php';
	
	# set visible div forum_messages
    include 'css.php';
	
	# Load my library
    include 'my_library.php';
	
	// setting the language 
    $lan = $_SESSION['lan'];

    // set DB
	$dbname = $_SESSION['dbname'];
	$link = $_SESSION['link'];
    $lan_Name_theme50 = $lan["Name_theme50"];	
	
	// $autor_registr = 'yes' - there is registration
	$autor_registr = $_SESSION['autor_registr'];
	
	// get name table for answer
	$q=$_GET['q'];

	$lan_Forum_Manufacturer_on_line_header = $lan["Forum_Manufacturer_on_line_header"];
	$lan_Enter_theme_name = $lan["Enter_theme_name"];
	$lan_Enter_new_Record = $lan["Enter_new_Record"];
	$lan_Enter_new_Record600 = $lan["Enter_new_Record600"];
	
    $str1 = '
         <div id="Forum_Rules_header">
			<div id="Forum_Rules_header_txt">'. $lan_Forum_Manufacturer_on_line_header.'</div>
		</div>		
		<div id="Forum_Rules_wrapper">  
		  <div id="table_rules">
		    <div id="answer_Theme"> 			
		    </div>
		    <div id="answer2_Theme">			
		    </div>		   
		  </div>		  
		</div>
		
		<div id="forma_Theme">
			<div id="forma_Theme_txt">
				'. $lan_Enter_theme_name.':* <br/>
			</div>		
			<div id="name_Theme">			
			  <input  id="name_Theme2" type="text" size="52" name="name_Theme3" /><br/>
			</div>		  
			<div id="button_rules1">
			    <input  id="button" type="button" name="OK_rules" value="OK" onClick="OK_Add_Theme(2)" /><br/>
		    </div>	  
			<div id="button_rules1_txt">
			   *'.$lan_Name_theme50.'
			</div>
		</div>
		
		<div id="forma_Record">
			<div id="forma_Record_txt">
				'.$lan_Enter_new_Record.':* <br/>
			</div>		
			<div id="name_Record">			
			  <textarea id="name_Record2" name="name_Record3"
			       cols="120" rows="5" wrap="off" autofocus></textarea><br>
			</div>	
			<div id="button_record1_txt">
			   *'.$lan_Enter_new_Record600.'
			</div>			
			<div id="button_record_rules1">
			    <input  id="button" type="button" name="OK_Record" value="OK" onClick="OK_Add_Record()" /><br/>
		    </div>	  	
		</div>
		
		<div id="out_forma_Theme">
			<img   src="img/out.jpg" width="12" height="12" onClick="out_forma_Theme()" />			
		</div>
	';
	 echo $str1;

	 
	// Reading themes from table theme_Manufacturer and writing in HTML
    $tablename = 'Theme_manufacturer';	
    if (mysql_table_seek($tablename, $dbname))
	{
	  if ($link)
	  {
	    $query = "SELECT * FROM ".$tablename;
		$result = mysql_query($query) or die("Invalid query: " . mysql_error());
	  }	
	  $str3 = '<div id="rab0404">
	    <style> #rab0404 {background: #696969;
		                  color: white;
		}</style>
  &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;'.$lan["Theme"].'
  &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;'.$lan["Author"].'
  &emsp;&emsp;'.$lan["Replies"].'
  &emsp;'.$lan["Viewed"].'
  &emsp;&emsp;&emsp;'.$lan["Last_Reply"].'
			     </div>';
	  echo  $str3;	
      while ($row2 = mysql_fetch_array($result, MYSQL_BOTH)) 
	  {   
	    //calculate all answers in table of answer and  last answer
	    $name_theme_answer = $row2["Theme_name_answer"];
		$Theme_users_id = $row2["Theme_users_id"];
		if (mysql_table_seek($name_theme_answer, $dbname) )
		{
		    //calculate all answers in table of answer
			$kol_zap_Theme_name_answer = last_id($name_theme_answer, 'Theme_Manufacturer_id');	
		
			// date,time, id in last answer
			if ($kol_zap_Theme_name_answer > 0)
			{
	          $query = "SELECT Theme_Manufacturer_x_user_id, Theme_Manufacturer_data, Theme_Manufacturer_time FROM " . $name_theme_answer. " WHERE Theme_Manufacturer_id=".$kol_zap_Theme_name_answer;
			  $result2 = mysql_query($query) or die("Invalid query: " . mysql_error());
			  while ($row = mysql_fetch_assoc($result2)) 
			  {
 			    $data_last_answer = $row['Theme_Manufacturer_data'];
			    $time_last_answer = $row['Theme_Manufacturer_time'];
     		    $Theme_Rules_x_user_id = $row['Theme_Manufacturer_x_user_id'];
              }
			  mysql_free_result($result2);
			  
			  // read login for last answer
			  if (mysql_table_seek('users', $dbname))
			  {
   			    $query = "SELECT users_login FROM users WHERE users_id=".(string)$Theme_Manufacturer_x_user_id;				
				$result4 = mysql_query($query) or die("Invalid query: " . mysql_error());
				while ($row = mysql_fetch_assoc($result4)) 
			    {				
 			      $theme_users_login_last_answer = $row['users_login'];
                }
			    mysql_free_result($result4);
			  }	
			} // if
			else // table $name_theme_answer exist but no any records
			{
			  $data_last_answer = '';
			  $time_last_answer = '';
			  $Theme_kol_users = '';
			}
			
		}
		else echo 'Not exist table ' . $name_theme_answer;		

		// read login for Theme_users_id
        if (mysql_table_seek('users', $dbname))
	    {		
		  $query = "SELECT users_login FROM users WHERE users_id=".$Theme_users_id;
		  $result4 = mysql_query($query) or die("Invalid query: " . mysql_error());
		  while ($row = mysql_fetch_assoc($result4)) 
		  {
 		    $theme_users_login = $row['users_login'];
          }
		  mysql_free_result($result4);
		}			
		// writing in HTML		
		$list_Theme_text = $row2['Theme_text'];	
		$list_Theme_kol_users=$row2['Theme_kol_users_viewer'];
//echo 'name_theme_answer = '.$name_theme_answer;
$length_number = strlen($name_theme_answer)-12;
//echo ' length_number = '.$length_number;
$number_name_theme_answer = (int)(substr($name_theme_answer,12,$length_number));	
//echo 'number_name_theme_answer = '.$number_name_theme_answer;
		$str1 = '<div id="Theme_add">	
		            <table name="Theme_s" width="1000"  align="middle" valign="middle" cellspacing="0" rules="rows" border="1">
			          <tr bgcolor="#b3b3b3" align="middle">
			            <td width= "500" id="Theme_txt1">'.
						'<SPAN onClick="list_theme_rules('.$number_name_theme_answer.')">'.$list_Theme_text.'</SPAN></td>

					    <td width= ""140"" id="Theme_txt2">'.$theme_users_login.'</td>
					    <td width= "80" id="Theme_txt3">'.$kol_zap_Theme_name_answer.'</td>
					    <td width= "80" id="Theme_txt4">'.$list_Theme_kol_users.'</td>
					    <td width= "200" id="Theme_txt5">' . $data_last_answer .'&emsp;'. $time_last_answer . '<br/>' . $theme_users_login_last_answer . '</td>
					  </tr>			
		            </table>
                  </div>';
        echo  $str1;	
      }  //while  

	  //  writing in HTML	button Append Theme
      $lan_Add_Theme=$lan["Add_Theme"];	  
	  $lan_back_record=$lan["Back_Record"];
	  $str1 = '<div id="Forum_Rules_button_add"> 
		          <div id="button_add_Theme">
			        <input  id="button" type="button" name="add_Theme" value="'.$lan_Add_Theme.'" onClick="Add_Theme()" />
		          </div>
                  <div id="button_back_record">
			       <input  id="#button_back_record2" type="button" name="back_Rules" value="'.$lan_back_record.'" onClick="Back_Rules()"  />
		          </div>					  
		       </div>';
	  echo  $str1;
	  
	}  //if
	 
?>