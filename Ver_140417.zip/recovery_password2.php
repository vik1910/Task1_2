<?php
// recovery_password2.php � recovery password (step 2)
//phpinfo();
  session_start();
  
  $lan = $_SESSION['lan'];
  include ('config.php'); 
  # ���������
   //   header('Content-Type: text/html; charset=windows-1251');
   
    $lan_n_o_registred_user=$lan['n_o_registred_user'];
	$lan_email_rec=$lan['email_rec'];
	$lan_Input=$lan['Input'];
	$lan_err8=$lan['err8'];
	$lan_err5=$lan['err5'];
	$lan_err4=$lan['err4'];
	$lan_Email_to_user=$lan['Email_to_user'];
	$lan_Press_OK_to_continue=$lan['Press_OK_to_continue'];
	$lan_your_new_password=$lan['your_new_password'];

    // �������� ���������� ����� post
    $login = iconv("UTF-8", "Windows-1251", $_POST['login']);
	$email_rec_p_value = iconv("UTF-8", "Windows-1251", $_POST['email_rec_p_value']);
//echo '$login ='.$login;	
//echo '$email_rec_p_value ='.$email_rec_p_value;	
    // �������� �������
    $login1 = trim($login);
	$email_rec_p_value1 = trim($email_rec_p_value);
    // ���������� ������� �������
    $login2 = htmlspecialchars($login1);
	$email_rec_p_value2 = htmlspecialchars($email_rec_p_value1);
//echo '$email_rec_p_value2 = '.$email_rec_p_value2;
	// �������� ���������� ������: ���� ������ ����� � ������
    if($login2 != '') 
	{	
	
	  if($email_rec_p_value2 != '') 
	  {	
	    # ���������,  ��������� �� ������������ � ����� ������:
		$data = mysql_fetch_assoc(mysql_query("SELECT users_id, users_email, users_status  FROM `users` 
	    WHERE `users_login`='".mysql_real_escape_string($_POST['login'])."' LIMIT 1")); 
       if(COUNT($data) > 0) 
       {  
	     $email2 = $data['users_email']; 
//echo '3 $email2 ='.$data['users_status'].$data['users_email'];		 
 
         if ($email2 != $email_rec_p_value2) //Emails are different '
		 {
		   echo 
		   '
		     <style>
                  #authoriz1 {visibility: hidden;}
				  #author {visibility: hidden;}
				  #content_left {visibility: hidden;}
				  				  
             </style>
	         <div id="messages_err">
		        <br/>
                <img src="img/error.png" align="left">
		        <p align="center"><font color="red">'.$lan_err4.'<br/>'.$lan_Press_OK_to_continue.'</font></p><br/><br/>
                <div style="clear:left;"></div><br/>
		        <div id="button_ok">
				  <input  id="button_ok2" type="button"  align="middle" name="ok_reg" value="OK" onClick="out3_autoriz_err()" />
                </div>
             </div><br/>
		   ';
         }
		 else 
		 {
		   if($email_rec_p_value2 == $email2) //mail correct - generate new password
		   {
		   
             $Back_Mail='vladik1910@gmail.com';//�������� �� ��������!!!!!!!!!!!!!!!!!
			 $new_password = generateCode(10); 
		     //send new password to the user
             //echo htmlentities("<html>");
             $orig ="<html>
		 
                       <head>
                         <title>New password</title>
                       </head>
                       <body>
                         <p>Please, verify your new password for site Article.com</p>
                         <p>".$new_password."</p>
                       </body>
                     </html>";
            $message_user = htmlentities($orig);
			$headers = "Content-type:�text/html;�charset=windows-1251�\r\n";
			$headers .= "From:�site Articles.com" . "<".$Back_Mail.">\r\n";
			$rab = mail($email2, $lan_Email_to_user, $message_user, $headers);//Send new password to user
			if($rab)
			{
			  $password2 = md5(md5(trim($new_password)));
			  mysql_query("UPDATE users SET users_password='".$password2."' WHERE users_login='".users_login2."'") 
			   or die("MySQL errors: " . mysql_errors());
			   // Password and Login are correct
		       $autor_registr = 'yes';
		       $_SESSION['autor_registr']=$autor_registr;
		       $_SESSION['login'] = $login2;
		       $_SESSION['users_id'] = $query['users_id'];
			}//if
			else echo 'some error happen (sending Email to user)';
		   }//if
		   
		 }//else  
	 
       }//if
	   else
	   {
	     echo 
		 '
	       <div id="messages_err">
		      <br/>
              <img src="img/error.png" align="left">
		      <p align="center"><font color="red">'.$lan_n_o_registred_user.'
		      '.$lan_Press_OK_to_continue.'</font></p><br/><br/>
              <div style="clear:left;"></div><br/>
		      <div id="button_ok">
				<input  id="button_ok2" type="button"  align="middle" name="ok_reg" value="OK" onClick="out_autoriz_err()" />
              </div>
           </div><br>
		 ';
	   }//else
	  

	  }//if	
	  else
	  {
	    echo 
		'
	        <div id="messages_err">
		      <br/>
              <img src="img/error.png" align="left">
		      <p align="center"><font color="red">'.$lan_err5.'
		      '.$lan_Press_OK_to_continue.'</font></p><br/><br/>
              <div style="clear:left;"></div><br/>
		      <div id="button_ok">
				<input  id="button_ok2" type="button"  align="middle" name="ok_reg" value="OK" onClick="out_autoriz_err()" />
              </div>
            </div><br>
		';   	   
	  }//else
	  
    }//if	
	else  //Login  wasn't inputed
	{
	  echo 
	  '
	        <div id="messages_err">
		      <br/>
              <img src="img/error.png" align="left">
		      <p align="center"><font color="red">'.$lan_err8.'
		      '.$lan_Press_OK_to_continue.'</font></p><br/><br/>
              <div style="clear:left;"></div><br/>
		      <div id="button_ok">
				<input  id="button_ok2" type="button"  align="middle" name="ok_reg" value="OK" onClick="out_autoriz_err()" />
              </div>
            </div><br>
	  ';   	   	  
	} //if

	function generateCode($length) 
    { 
        $chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPRQSTUVWXYZ0123456789"; 
        $code = ""; 
        $clen = strlen($chars) - 1;   
        while (strlen($code) < $length) { 
          $code .= $chars[mt_rand(0,$clen)];   
        }//while
        return $code; 
    } //function generateCode($length) 
?>  