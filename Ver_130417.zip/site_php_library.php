<?php
    session_start();
		   
    function table_articles()
    {
//echo '^^^^^^^^^^^^^';	
//echo "������� ����� - ".date("H:i:s");

		   
		   //changing language
           include 'language.php';
	
	       // ���������� ������
           include 'config.php';
		   
           $current_page = $_SESSION['current_page'];
		   $max_rows_page = $_SESSION['max_rows_page'];
		   
		   $login_user2 = $_SESSION['login_user'];
//echo '$current_page = '.$current_page;		   
		   $query = mysql_query("SELECT article_id, article_name, article_content, article_data, article_time  FROM `articles_table` 
	                WHERE `users_login`='".mysql_real_escape_string($login_user2)."' ");		
		   $number_rows = mysql_num_rows($query);
//echo '$max_rows_page = '.$max_rows_page;	
           if($number_rows > $max_rows_page){$_SESSION['all_pages'] = ceil($number_rows/$max_rows_page);}
		   else {$_SESSION['all_pages'] = 1;}
//		   $number_rows_last_page = $number_rows - (($_SESSION['all_pages'] - 1)* $max_rows_page);
		   if($current_page > $_SESSION['all_pages']) {$current_page = $_SESSION['all_pages'];}
		   if($current_page < 1) {$current_page = 1;}
		   if($number_rows > 0)//there are articles of this user
		   {
		     echo 
			 '    
		       <style>
			     #content_main3 {visibility:  visible;}
    	       </style>
			 ';
		     echo 
			 '      <br/>
 				    <div id="forma_box">
				      <table width="100%"  border="1" align="center" cellspacing="5" cellpadding="10">
					    <tr  height="5">
					      <th width="60%">'.$lan["Articles_Names"].'</th>
					      <th width="30%">'.$lan["Article_Tags"].'</th>
					      <th width="10%">'.$lan["Creation_Time"].'</th>						  
					    </tr>
		      ';
//echo '$lan["Articles_Names"] = '.$lan["Articles_Names"];
               if($number_rows > $_SESSION['max_rows_page']) {$number_rows_page = $_SESSION['max_rows_page'];}
			   else {$number_rows_page = $number_rows;}
			   
               $row_first = (($current_page - 1) * $max_rows_page) + 1;
			   $row_last = $current_page * $max_rows_page;
			   if($row_last > $number_rows) {$row_last = $number_rows;}
//echo '$row_first = '.$row_first;			   
//echo '$row_last = '.$row_last;
               if($row_first > 1)
			   for($i = 0; $i < $row_first-1; $i++)
			   {$data = mysql_fetch_assoc($query);}//if
		       for ($i = $row_first-1; $i < $row_last; $i++)//list of article
	           {
			   
			       $data = mysql_fetch_assoc($query); 
		           $t_article_name = $data['article_name'];
//echo '$t_article_name ='.$t_article_name;				   
				   $article_tads = $data['article_content'];
			       $article_data = $data['article_data'];
			       $article_time = $data['article_time'];
				   $article_data_time =  $article_data.' '.$article_time;
				   
				   //read tags of article
			       $t_article_tag = $data['article_id'];
			       $query2 = mysql_query("SELECT tag_id  FROM `articles_tags_table` 
	                          WHERE `article_id`='".mysql_real_escape_string($t_article_tag)."' ");		
		           $number_rows_tag = mysql_num_rows($query2);				   
                   $article_tags = '';	
                   if($number_rows_tag > 0)//there are tags
                   {				   
				        for ($k = 0; $k < $number_rows_tag; $k++)
	                    {
				            $data2 = mysql_fetch_assoc($query2);
						    $article_tag_id = $data2['tag_id'];
						    //read tag
						    $query3 = mysql_query("SELECT tag_name  FROM `tags_table` 
	                                  WHERE `tag_id`='".mysql_real_escape_string($article_tag_id)."'  LIMIT 1");
                            if(count($query3) == 0) {echo 'Error: there is not any tag in tags_table';}
                            else
                            {
							    $data3 = mysql_fetch_assoc($query3);
						        if($article_tags == '') {$article_tags = $data3['tag_name'];}
							    else $article_tags = $article_tags.' &nbsp; &nbsp; &nbsp;   '.$data3['tag_name'];
                            }//if						
				        }//for
				   }//if
//				   $result = mysql_query ("UPDATE articles_table");
//		           $result = mysql_query ("UPDATE tags_table");
//		           $result = mysql_query ("UPDATE articles_tags_table");
				   echo 
			       '
				        <tr  height="5">
					      <td width="60%">'.$t_article_name.'</td>
						  <td width="30%">'.$article_tags.'</td>
					      <td width="10%">'.$article_data_time.'</td>	
						</tr>
                   ';					
		       }//for
			   
			   //<option selected value="t4">����� ������</option>
			   $selected_page = 1;
			   $str1 = '<select name="select_page">';
			   $str2 = '';
			   for ($i = 0; $i < $number_rows; $i++)
	           {
	                $str2 = $str2.'<option onClick="choice_page()">'.$number_rows.'</option>';
	           }//for
			   //$number_rows 
			   echo 
			   '
                     </table>
				  </div>
			   ';	  
		   }//if
		   return '1';
    }//
?>
