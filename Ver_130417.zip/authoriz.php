<?php
// authoriz.php � Autorization og user;
  
  session_start();
  
  $lan = $_SESSION['lan'];
   
  # ���������
//   header('Content-Type: text/html; charset=windows-1251');
   
  # ������� ��� ��������� ��������� ������ 
  function generateCode($length=6) 
  { 
    $chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPRQSTUVWXYZ0123456789"; 
    $code = ""; 
    $clen = strlen($chars) - 1;   
    while (strlen($code) < $length) { 
        $code .= $chars[mt_rand(0,$clen)];   
    } 
    return $code; 
  } 

  # ���������� ������
  include 'config.php';

    //header('Content-Type: text/html;charset=windows-1251');  //���������
  
    $kod_flag = '0';
	$err = array();
 
	$lan_Authentication_is_successful=$lan['Authentication_is_successful'];
	$lan_Login_or_password_is_incorrect=$lan['Login_or_password_is_incorrect'];
	$lan_err7=$lan['err7'];
	$lan_err8=$lan['err8'];//No Login
	$lan_Press_OK_to_continue=$lan['Press_OK_to_continue'];
	$lan_confirm_your_Registration=$lan['confirm_your_Registration'];
	$lan_n_o_registred_user = $lan['n_o_registred_user'];
	$lan_N_o_login_and_password = $lan['N_o_login_and_password'];
 
    // �������� ���������� ����� post
    $login = iconv("UTF-8", "Windows-1251", $_POST['login']);
	$password = iconv("UTF-8", "Windows-1251", $_POST['password']);

    // �������� �������
    $login1 = trim($login);
	$password1 = trim($password);

    // ���������� ������� �������
    $login2 = htmlspecialchars($login1);
    $password2 = htmlspecialchars($password1);	
//echo '$login2 ='.$login2;       
   // �������� ���������� ������: ���� ������ ����� � ������
    if(($login2 != '') and ($password2 != '')) 
	{	
	  # ��������� �� �� ������, � ������� ����� ���������� ���������� 
      $data = mysql_fetch_assoc(mysql_query("SELECT users_id, users_password, users_status  FROM `users` 
	    WHERE `users_login`='".mysql_real_escape_string($_POST['login'])."' LIMIT 1")); 
	  if(count($data) > 0) //Login was founf
	  {
//echo 'count($data) = '.count($data);	  
      # ���������� ������ 
      if($data['users_password'] === md5(md5($_POST['password'])))
      { 
		if($data['users_status'] != 0) //There was a user's confirmation
		{
		  $_SESSION['login_user'] = $login2;
          # ���������� ��������� ����� � ������� ��� 
          $hash = md5(generateCode(10)); 
 
          # ���������� � �� ����� ��� ����������� 
          mysql_query("UPDATE users SET users_hash='".$hash."' 
		    WHERE users_id='".$data['users_id']."'") or die("MySQL Error: " . mysql_error()); 
	      
		  # ������ � ����� ����������
		  $autor_registr = 'yes';
		  $_SESSION['autor_registr']=$autor_registr;
		  $_SESSION['login'] = $login2;
		  $_SESSION['users_id'] = $data['users_id'];
		  //Authentication_is_successful
		  echo 
		  '
	         <div id="messages_ok">
		       <br/>
		       <img src="img/111.png" align="left" color="#30a0c6";>
		       <p align="center"><font>'.$lan_Authentication_is_successful.'<br/><br/>
		       '.$lan_Press_OK_to_continue.'</font></p><br/><br/>
		       <div id="button_ok">
				 <input  id="button_ok2" type="button"  align="middle" name="ok_reg" value="OK" onClick="out_autoriz_ok()" />
               </div>
             </div><br>
			 <style>
               #content_left {visibility:  hidden; }
             </style>;
		  ';

           $current_page = $_SESSION['current_page'];
		   $max_rows_page = $_SESSION['max_rows_page'];
		   
		   $login_user2 = $_SESSION['login_user'];
//echo '$current_page = '.$current_page;		   
		   $query = mysql_query("SELECT article_id, article_name, article_content, article_data, article_time  FROM `articles_table` 
	                WHERE `users_login`='".mysql_real_escape_string($login_user2)."' ");		
		   $number_rows = mysql_num_rows($query);
           if($number_rows > $max_rows_page){$_SESSION['all_pages'] = ceil($number_rows/$max_rows_page);}
		   else {$_SESSION['all_pages'] = 1;}
//echo '$_SESSION[all_pages] = '.$_SESSION['all_pages'];
        }//if	
		else //There wasn't a user's confirmation
		{
		  echo '
	         <div id="messages_err">
		          <br/>
                  <img src="img/error.png" align="left">
		          <p align="center"><font color="red">'.$lan_confirm_your_Registration.'<br/>
		          '.$lan_Press_OK_to_continue.'</font></p><br/><br/>
                  <div id="button_ok">
				    <input  id="button_ok2" type="button"  align="middle" name="ok_reg" value="OK" onClick="out2_autoriz_err()" />
                  </div>
             </div><br>';		
		}//else
	  }		
	  else //Password is not correct
	  {
	    echo '
	            <div id="messages_err">
		          <br/>
                  <img src="img/error.png" align="left">
		          <p align="center"><font color="red">'.$lan_Login_or_password_is_incorrect.'<br/>
		          '.$lan_Press_OK_to_continue.'</font></p><br/><br/>
                  <div id="button_ok">
				    <input  id="button_ok2" type="button"  align="middle" name="ok_reg" value="OK" onClick="out2_autoriz_err()" />
                  </div>
                </div><br>';
	  } //if
	  }//if
	  else //There is not  registred user with this Login
	  {
	    echo '
	            <div id="messages_err">
		          <br/>
                  <img src="img/error.png" align="left">
		          <p align="center"><font color="red">'.$lan_n_o_registred_user.'<br/>
		          '.$lan_Press_OK_to_continue.'</font></p><br/><br/>
                  <div id="button_ok">
				    <input  id="button_ok2" type="button"  align="middle" name="ok_reg" value="OK" onClick="out_autoriz_err()" />
                  </div>
                </div><br>
		    ';
	  }//else
	}//if
    else  //Login or Password wasn't inputed
	if(($password2 == '') and ($login2 != ''))
	{
	   echo '
	         <div id="messages_err">
		       <br/>
               <img src="img/error.png" align="left">
		       <p align="center"><font color="red">'.$lan_err7.'<br/>
		       '.$lan_Press_OK_to_continue.'</font></p><br/><br/>
               <div style="clear:left;"></div><br/>
		       <div id="button_ok">
				 <input  id="button_ok2" type="button"  align="middle" name="ok_reg" value="OK" onClick="out5_autoriz_err()" />
               </div>
             </div><br>
			';
    }//if
    else//No Login
	if(($password2 != '') and ($login2 == ''))
    {
	   echo '
	         <div id="messages_err">
		       <br/>
               <img src="img/error.png" align="left">
		       <p align="center"><font color="red">'.$lan_err8.'<br/>
		       '.$lan_Press_OK_to_continue.'</font></p><br/><br/>
               <div style="clear:left;"></div><br/>
		       <div id="button_ok">
				 <input  id="button_ok2" type="button"  align="middle" name="ok_reg" value="OK" onClick="out4_autoriz_err()" />
               </div>
             </div><br>
			';
    }//else
	else
    if(($login2 == '') and ($password2 == ''))
	{
	  echo '
	         <div id="messages_err">
		       <br/>
               <img src="img/error.png" align="left">
		       <p align="center"><font color="red">'.$lan_N_o_login_and_password.'<br/>
		       '.$lan_Press_OK_to_continue.'</font></p><br/><br/>
               <div style="clear:left;"></div><br/>
		       <div id="button_ok">
				 <input  id="button_ok2" type="button"  align="middle" name="ok_reg" value="OK" onClick="out4_autoriz_err()" />
               </div>
             </div><br>
		   ';
	}//if		
  
?>  
