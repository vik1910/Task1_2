<?php  // form for adding an article
	session_start();
// echo '==============';
	global $lang, $lan,  $autor_registr;
	
	////changing language
    include 'language.php';
	
	# ���������� ������
    include 'config.php';
	
	$login_user2 = $_SESSION['login_user'];
	
	//form for adding article
			 echo '
                  <style>
				      #forma_article{
                          display: block;
					  } 
				  </style>
		      ';
	echo '
	         <form name="forma_add_article" id="forma_article" method="post" action="">
			    <div id="title_forma_article"><h1>'.$lan["Fotma_for_adding_article"].'</h1></div>
			    <div id="Name_article">
                            '.$lan["Name_article"].':<br />
							<input id="Name_article_auto" type="text" name="Name_article" value="" size="135" maxlength="100"  autofocus/>
				</div>
				<div id="Content_article">
                            '.$lan["Text_article"].':<br />
							<textarea rows="20" cols="138" name="text_form_article" wrap="soft">						
							</textarea> 							
				</div>
				<div id="bl_URL_adress">
				  '.$lan["URL_adress"].':<br />
					<input id="st_URL_adress" type="text" name="name_URL_adress" value="" size="135" maxlength="200" />
				</div>
				<div id="Article_Tags">
				  '.$lan["Tags"].':
			      <br />
			      '.$lan["Add_Tag"].':
			      <input id="Name_tag_auto" type="text" name="Name_tag" value="" size="30"   />
			      <input id="button_tag_add" type="button" name="tag_add" size="20" value="'.$lan["Save"].'" onClick="save_tag()" />
			      <br />
				</div>
  				<input id="button_submit_tag" type="button" name="name_submit_tag" size="100" value="'.$lan["Send"].'" onClick="add_data_form_a()" />			 
				<input id="button_cancel_tag" type="button" name="name_cancel_tag" size="100" value="'.$lan["cancel"].'" onClick="cancel_form_a()" />			 
			 </form>
	    ';
?>