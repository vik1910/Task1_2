<?php
DROP DATABASE articles_bd;
?> 

