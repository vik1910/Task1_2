<?php // forum_check.php - call modul Forum
	session_start();
	// setting the language 
	if (isset($_SESSION['lang2']))
	{
	  if ($_SESSION['lang2'] == 'eng')
		{
			$lang = 'eng';
		}
		{
			$lang = 'rus';
		}
	}
	else
	{
		$_SESSION['lang2']='rus';	
		$lang = 'rus';
	}

	$autor_registr=$_SESSION['autor_registr'];

	if ($autor_registr == 'yes')
	{
		include'forum.php';
	}
	else
	{
		include 'index.php';
		include 'css.php';
	}
	
?>