<?php
// Add_Theme.php - �������� ��������� ���� � �� � ������� ������ 

	session_start();	
	
	# Load my library
    include 'my_library.php';
	
    # ���������� ������
    include 'config.php';
	
	// set language
	$lan = $_SESSION['lan'];

	// set DB
	$dbname = $_SESSION['dbname'];
	$link = $_SESSION['link'];
	
	// get new theme using post
    $str = iconv("UTF-8", "Windows-1251", $_POST['name_Theme']);
	
	// Get name_Theme2 and n_section
	if (!trim_2_param($str,$name_Theme2,$n_section))
	{echo "name_Theme is't correct!";}
	
	$theme_user_login=mysql_real_escape_string($_SESSION['login']);	// login user of theme	
	$lan_Enter_theme_name = $lan["Enter_theme_name"];
	$lan_Enter_new_Record = $lan["Enter_new_Record"];
	$lan_Enter_new_Record600 = $lan["Enter_new_Record600"];
	
	switch ($n_section) 
	{
      case '1':
        $file_Theme = 'Theme_Rules';
		$lan_Forum_Rules_header_lan = $lan["Forum_Rules_header_lan"];		
		$file_answer = 'Theme_Rules';
        break;
      case '2':
        $file_Theme = 'Theme_manufacturer';
		$lan_Forum_Rules_header_lan = $lan["Forum_Manufacturer_on_line_header"];
		$file_answer = 'Theme_manuf';
        break;
     case '3':
        $file_Theme = 'Conferences';
		$lan_Forum_Rules_header_lan = $lan["Forum_Conference_hall"];
		$file_answer = 'Conferences';
        break;		
     case '4':
        $file_Theme = 'Ta_Database';
		$lan_Forum_Rules_header_lan = $lan["Forum_Tanks_Database"];
		$file_answer = 'Ta_Database';
        break;
     case '5':
        $file_Theme = 'Tan_Reviews';
		$lan_Forum_Rules_header_lan = $lan["Forum_Tanks_owners"];
		$file_answer = 'Tan_Reviews';
        break;	
		
     case '6':
        $file_Theme = 'Tr_Database';
		$lan_Forum_Rules_header_lan = $lan["Forum_Tractors_Database"];
		$file_answer = 'Tr_Database';
        break;	
     case '7':
        $file_Theme = 'Tra_Reviews';
		$lan_Forum_Rules_header_lan = $lan["Forum_Tractors_owners"];
		$file_answer = 'Tra_Reviews';
        break;	
		
     case '8':
        $file_Theme = 'Shoppingdoc';
		$lan_Forum_Rules_header_lan = $lan["Forum_Shopping_doc"];
		$file_answer = 'Shoppingdoc';
        break;	
     case '9':
        $file_Theme = 'Shopping_3D';
		$lan_Forum_Rules_header_lan = $lan["Forum_Shopping_3D"];
		$file_answer = 'Shopping_3D';
        break;				
		
    }  //  switch
// echo 'file_Theme='.$file_Theme;			
    $str1 = '
         <div id="Forum_Rules_header">
			<div id="Forum_Rules_header_txt">'. $lan_Forum_Rules_header_lan.'</div>
		</div>		
		<div id="Forum_Rules_wrapper">  
		  <div id="table_rules">
		    <div id="answer_Theme"> 			
		    </div>
		    <div id="answer2_Theme">			
		    </div>		   
		  </div>		  
		</div>
		
		<div id="forma_Theme">
			<div id="forma_Theme_txt">
				'. $lan_Enter_theme_name.':* <br/>
			</div>		
			<div id="name_Theme">			
			  <input  id="name_Theme2" type="text" size="52" name="name_Theme3" /><br/>
			</div>		  
			<div id="button_rules1">
			    <input  id="button" type="button" name="OK_rules" value="OK" onClick="OK_Add_Theme('.$n_section.')" /><br/>
		    </div>	  
			<div id="button_rules1_txt">
			   *'.$lan_Name_theme50.'
			</div>
		</div>
		
		<div id="forma_Record">
			<div id="forma_Record_txt">
				'.$lan_Enter_new_Record.':* <br/>
			</div>		
			<div id="name_Record">			
			  <textarea id="name_Record2" name="name_Record3"
			       cols="120" rows="5" wrap="off" autofocus></textarea><br>
			</div>	
			<div id="button_record1_txt">
			   *'.$lan_Enter_new_Record600.'
			</div>			
			<div id="button_record_rules1">
			    <input  id="button" type="button" name="OK_Record" value="OK" onClick="OK_Add_Record()" /><br/>
		    </div>	  	
		</div>
		
		<div id="out_forma_Theme">
			<img   src="img/out.jpg" width="12" height="12" onClick="out_forma_Theme()" />			
		</div>
	';
	 echo $str1;
	
	// Write new Theme in DB
	if (strlen($name_Theme2) > 0)
	{
	  // id author Theme
	  $Theme_users_id2 = $_SESSION['users_id'];

	  // Number of viewer
	  $Theme_kol_users_viewer2 = 1;  // number of viewers
	  
	  // create table $file_Theme 
	  if (! mysql_table_seek($file_Theme, $dbname))
	  {  $sql = "CREATE TABLE IF NOT EXISTS ".$file_Theme."
          ( Theme_id INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
            Theme_users_id INT(11) NOT NULL,      
            Theme_kol_users_viewer INT(11) NOT NULL,
			Theme_text VARCHAR(50) NOT NULL,
			Theme_name_answer VARCHAR(15) NOT NULL,
			Theme_data DATE NOT NULL,
			Theme_time TIME NOT NULL,
			PRIMARY KEY  (Theme_id) 
		  ) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1;
         ";
	    $add_table=mysql_query($sql, $link);
	    if (! $add_table) {echo 'Error: table '.$file_Theme.' didnt create';}
	  }
	  
	  // name file of replys
	  $last_id_Theme_Rules = last_id($file_Theme, 'Theme_id') + 1;
	  if (!$last_id_Theme_Rules)
	  {  $last_id_Theme_Rules = 1; } 
	  $Theme_name_answer2 = $file_answer.'_'.(string)$last_id_Theme_Rules;
// echo '$Theme_name_answer2 ='.$Theme_name_answer2;
	  // Data and Time of creating Theme
	  $Theme_data2 = (string)date("Y.m.d");
	  $Theme_data2_UKR = Time_To_UKR($Theme_data2);
	  
	  $Theme_time2 = (string)date("H:i"); //(����� ����� ��������� � �������: 13:45) 
	  
	  // Writing in table  $file_Theme
	  
	  $query="INSERT INTO ".$file_Theme."  
           (Theme_users_id, Theme_kol_users_viewer, Theme_text, Theme_name_answer, Theme_data, Theme_time) 
           VALUES ( ".(string)$Theme_users_id2.",".(string)$Theme_kol_users_viewer2.",'$name_Theme2','$Theme_name_answer2',
		   '$Theme_data2','$Theme_time2')";	

	  $add_Theme = mysql_query($query, $link); 

	  // Search name last file for $file_Theme
	  $kol_Theme_Rules_answer = 0;
	  if ($add_Theme) 
	  { 
	    // calculate number of file-answer
	    $kol_Theme_Rules_answer = 1;     
	    $tablename = $file_Theme.'_1';

	    // Create new table for new Theme-Answer
	    $sql = "CREATE TABLE IF NOT EXISTS "
          .$Theme_name_answer2.
        " (
			Theme_Rules_id INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  			Theme_Rules_Theme_id INT(11) NOT NULL,
			Theme_Rules_x_user_id INT(11) NOT NULL,
			Theme_Rules_text VARCHAR(600) NOT NULL,
			Theme_Rules_data DATE NOT NULL,
			Theme_Rules_time TIME NOT NULL,
			PRIMARY KEY  (Theme_Rules_id)
		  ) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1; 
        ";
		
	    $add_table=mysql_query(mysql_query($sql, $link));
		
		// Add first record into table Theme_name_answer2
		$Theme_Rules_Theme_id = '1';
		$query="INSERT INTO " .$Theme_name_answer2. " (Theme_Rules_x_user_id, Theme_Rules_text, Theme_Rules_data, Theme_Rules_time) 
           VALUES (".$Theme_users_id2.", '$name_Theme2', '$Theme_data2', '$Theme_time2')";		   
	    $add_Theme = mysql_query($query) or die("Invalid query: " . mysql_error()); 
		
		// if (!$add_table) {echo 'Error: table Theme_name_answer didnt create';}
	  } //if 
	  else {echo 'Error during writing in table  Theme_Rules';}
	  
	  // Reading themes from table $file_Theme and writing in HTML
      $tablename = $file_Theme;	
      if (mysql_table_seek($tablename, $dbname))
	  {
	    if ($link)
	    {
		  $result = mysql_query("SELECT * FROM ".$tablename) or die("Invalid query: " . mysql_error());
	    }
        $str3 = '<div id="rab0404">
	      <style> #rab0404 {background: #696969;
		                  color: white;
		}</style>
  &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;'.$lan["Theme"].'
  &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;'.$lan["Author"].'
  &emsp;&emsp;&emsp;&emsp;'.$lan["Replies"].'
  &emsp;'.$lan["Viewed"].'
  &emsp;&emsp;&emsp;'.$lan["Last_Reply"].'
			     </div>';
	    echo  $str3;	 		
        while ($row2 = mysql_fetch_array($result, MYSQL_BOTH)) 
	    {   
		  $name_Theme2 = $row2['Theme_text'];
		  
		  // calculate kol_Theme_Rules_answer
		  $tablename2 = $row2['Theme_name_answer'];
		  $name_theme_answer = $tablename2;
		  $kol_Theme_Rules_answer = calc_all_records($tablename2, $dbname);
		  
          $length_number = strlen($tablename2)-12;
          //echo ' length_number = '.$length_number;
          $number_name_theme_answer = substr($name_theme_answer,12,$length_number);		  
		  
		  $Theme_kol_users_viewer2 = $row2['Theme_kol_users_viewer'];
		  
		  // date,time, id in last answer
		  if ($kol_zap_Theme_name_answer > 0)
		  {
	          $query = "SELECT Theme_Rules_x_user_id, Theme_Rules_data, Theme_Rules_time FROM " . $name_theme_answer. " WHERE Theme_Rules_id=".$kol_zap_Theme_name_answer;
			  $result2 = mysql_query($query) or die("Invalid query: " . mysql_error());
			  while ($row = mysql_fetch_assoc($result2)) 
			  {
// 			    $data_last_answer = Time_To_UKR($row['Theme_Rules_data']);
 			    $data_last_answer = Time_To_UKR($row['Theme_Rules_data']);	
//echo '$data_last_answer='.$data_last_answer;				
			    $time_last_answer = $row['Theme_Rules_time'];
     		    $Theme_Rules_x_user_id = $row['Theme_Rules_x_user_id'];
              }
			  mysql_free_result($result2);
		    
	
			  // read login for last answer
			  if (mysql_table_seek('users', $dbname))
			  {
   			    $query = "SELECT users_login FROM users WHERE users_id=".(string)$Theme_Rules_x_user_id;				
				$result4 = mysql_query($query) or die("Invalid query: " . mysql_error());
				while ($row = mysql_fetch_assoc($result4)) 
			    {				
 			      $theme_users_login_last_answer = $row['users_login'];
                }
			    mysql_free_result($result4);
			  }	
		  } // if
		  else // table $name_theme_answer exist but no any records
		  {
//			  $data_last_answer = Time_To_UKR($Theme_data2);
			  $data_last_answer = Time_To_UKR($Theme_data2);	
//echo '$data_last_answer='.$data_last_answer;			  
			  $time_last_answer = $Theme_time2;
			  $Theme_kol_users = '';
			  $theme_users_login_last_answer = $theme_user_login;
          }
  
		  // search login of athor theme by Theme_users_id 
		  $Theme_users_id2 = $row2['Theme_users_id'];
		  $theme_user_login = search_records('users', 'users_id', $Theme_users_id2, 'users_login', $dbname); 
		  if (! $theme_user_login) {$theme_user_login = '';}

          // write data of new Theme in HTML
	      echo 
	      '<div id="Theme_add">
		       <table name="Theme_s" width="1000";  align="middle" valign="middle">
			      <tr bgcolor="#b3b3b3" align="middle">										  

					
					<td width= "500" id="Theme_txt1">'.
						'<SPAN onClick="list_theme_rules('.$number_name_theme_answer.')">'.$name_Theme2.'</SPAN></td>
					
					<td width= "140" id="Theme_txt2">'.$theme_user_login.'</td>
					<td width= "80" id="Theme_txt3">'.$kol_Theme_Rules_answer.'</td>
					<td width= "80" id="Theme_txt4">'.$Theme_kol_users_viewer2.'</td>
					<td width= "200" id="Theme_txt5">'.$data_last_answer.'&nbsp;&nbsp;'.$time_last_answer.'<br/>'.$theme_users_login_last_answer.'</td>
			      </tr>			
	          </table>
          </div>
	      ';		  
		} // while
		
	  } // if
	  
    } // if 
    //  writing in HTML	button Append Theme
    $lan_Add_Theme=$lan["Add_Theme"];	  
	$lan_back_record=$lan["Back_Record"];
	$str1 = '<div id="Forum_Rules_button_add"> 
	         <div id="button_add_Theme">
	          <input  id="button" type="button" name="add_Theme" value="'.$lan_Add_Theme.'" onClick="Add_Theme()" />
	         </div>
                <div id="button_back_record">
		          <input  id="#button_back_record2" type="button" name="back_Rules" value="'.$lan_back_record.'" onClick="Back_Rules()"  />
		        </div>					  
		     </div>';
	echo  $str1;
?>