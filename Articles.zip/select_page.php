<?php  //select_page.php  -  go to selected page
          session_start();
//$file = 'DEBUGGING.txt';
//$current = file_get_contents($file);	 
		   //changing language
           include 'language.php';
	
	       // ���������� ������
           include 'config.php';
		   
		   # include my php-lib
           include 'site_php_library.php';

	   
		   $_SESSION['current_page'] = strip_tags(substr($_POST['search_term'],0, 100));
//$current .= '   select_page.php:  $_SESSION[current_page] = '.$_SESSION['current_page'];
//file_put_contents($file, $current);	
           $current_page = $_SESSION['current_page'];
		   $_SESSION['current_row_table']= -1; //number of selected row on current page

//$current .= '   select_page.php:  $_SESSION[current_row_table] = '.$_SESSION['current_row_table'];
//file_put_contents($file, $current);				   
//	       echo 
//		   '
//		     		<div id="articles_content1">
//					</div>
//           ';   
//	       echo '<div id="articles_content2">';
           $rab = table_articles();//List of Articles
//	       echo '</div>';
?>