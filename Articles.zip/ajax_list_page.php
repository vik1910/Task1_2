<?php  //ajax_list_page - creating pages list
          session_start();
//$file = 'DEBUGGING.txt';
//$current = file_get_contents($file);	 
		   //changing language
           include 'language.php';
	
	       // ���������� ������
           include 'config.php';
		   
		   # include my php-lib
           include 'site_php_library.php';
		   
           $current_page = $_SESSION['current_page'];
		   $_SESSION['current_row_table']= -1; //number of selected row on current page
	   
		   $all_pages = $_SESSION['all_pages'];	   
  
            $str2 = '<form id="form_number_page" name="name_form_number_page"  method="post">
			            <select id="select_number_page" name="name_select_number_page" size="1"  
						        multiple="multiple" onchange="select_page();">';
            for ($i = 1; $i <= $_SESSION['all_pages']; $i++)
            {
                 $str2 = $str2.'<option value='.$i.'>'.$i.'</option>';
            }//for
            $str3 = '</select></form>';
            echo $str2.$str3;
//$current .= '   ajax_list_page.php:  $_SESSION[current_page] = '.$_SESSION['current_page'];
//file_put_contents($file, $current);
?>