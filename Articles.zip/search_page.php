<?php  //search_page.php - searching first and next article and page with this tag
          session_start();

		   //changing language
           include 'language.php';
	
	       // ���������� ������
           include 'config.php';
		   
		   # include my php-lib
           include 'site_php_library.php';
//$file = 'DEBUGGING.txt';
//$current = file_get_contents($file);
	       $login_user = $_SESSION["login_user"];
		   $rab_next = strip_tags(substr($_POST['search_term'],0, 100));
//$current .= '   search_page.php   rab_next = '.$rab_next;
//file_put_contents($file, $current);		   
		   if($rab_next != '999') 
		   {
		       $_SESSION['current_tag'] = $rab_next;
			   $_SESSION["array_user_articles_tag"] = array();
			   $_SESSION['index_array_user_articles_tag'] = 0;
		   }//if
           else 
		   {
//$current .= '   99998  rab_next = '.$rab_next;
//file_put_contents($file, $current);			   
		       $_SESSION['index_array_user_articles_tag'] = $_SESSION['index_array_user_articles_tag'] + 1;
//$current .= '   999777:  $_SESSION[index_array_user_articles_tag] = '.$_SESSION["index_array_user_articles_tag"];
//file_put_contents($file, $current);			   
			   if($_SESSION['index_array_user_articles_tag'] > count($_SESSION["array_user_articles_tag"])-1)
			   {
			       $_SESSION['index_array_user_articles_tag'] = 0;
			   }//if
		   }//else
		   $search_tag = $_SESSION['current_tag'];
//$current .= '   999888:  $_SESSION[index_array_user_articles_tag] = '.$_SESSION["index_array_user_articles_tag"];
//file_put_contents($file, $current);		   
//$current .= '   9999999999:  $_SESSION[current_tag] = '.$_SESSION["current_tag"];
//file_put_contents($file, $current);


		   //defenition $array_user_articles - all article of this user
		   $query = "SELECT article_id FROM articles_table WHERE 
      		          users_login="."'".$login_user."'";
		   $data = mysql_query($query); 
		   $_SESSION["array_user_articles"] = array();//all article of this user
		   while($data2 = mysql_fetch_assoc($data))
		   {
		       if(count($data2) > 0)
		       {$_SESSION["array_user_articles"][count($_SESSION["array_user_articles"])] = 
			       $data2['article_id'];
               }//if
		   }//while
//$current .= '   66:  count($_SESSION[array_user_articles])  = '.count($_SESSION["array_user_articles"]) ;
//file_put_contents($file, $current); 

		   $search_tag = stripWhitespaces($search_tag);
		   $search_tag = mysql_real_escape_string($search_tag);
		   $query = "SELECT tag_id FROM tags_table WHERE 
      		          tag_name="."'".$search_tag ."'"."  LIMIT 1";
//$current .= '   1:  query = '.$query;
//file_put_contents($file, $current);					  
           $data = mysql_query($query); 
		   $n_id_tag = mysql_num_rows($data);
//$current .= '   2:  $n_id_tag = '.$n_id_tag;
//file_put_contents($file, $current); 
           $data2 = mysql_fetch_assoc($data);
		   if($n_id_tag == 0) {echo '<br>Invalid query: ' . mysql_error();}
		   else //there is tag in DB 
		   {
		       $search_id_tag = $data2['tag_id'];
//$current .= '   3:  $_search_id_tag = '.$search_id_tag;
//file_put_contents($file, $current); 

               $query = "SELECT article_id FROM articles_tags_table WHERE 
      		          tag_id="."'".$search_id_tag ."'";
               $data = mysql_query($query);
			   
			   $array_article_id = array();
			   
			   while($data2 = mysql_fetch_assoc($data))
			   {
//$current .= '   4:  count($data2) = '.count($data2);
//file_put_contents($file, $current); 
			       if(count($data2) > 0)
			       {$array_article_id[count($array_article_id)] = $data2['article_id'];}
//$current .= '   5:  count($array_article_id) = '.count($array_article_id);
//file_put_contents($file, $current); 
			   }//while
               if(count($array_article_id) > 0) //there is article for this tag
			   {
			       for ($i = 0; $i < count($array_article_id); $i++)
	               {
			           $query = "SELECT article_id FROM articles_table WHERE  article_id=".
					   "'".$array_article_id[$i]."'".
								 "AND  users_login="."'".$login_user."'";
                       $data = mysql_query($query);
			          
			           while($data2 = mysql_fetch_assoc($data))
			           {
			               if(count($data2) > 0)
			               {$_SESSION["array_user_articles_tag"][count($_SESSION["array_user_articles_tag"])] = 
						        $data2['article_id'];} //array of article_id with this tag
//$current .= '   6===:  $data2[article_id] = '.$data2['article_id'];
//file_put_contents($file, $current); 
			           }//while
				   }//for
				   $_SESSION["current_article_tag"] = 
				      $_SESSION["array_user_articles_tag"][$_SESSION['index_array_user_articles_tag']]; //curent article_id with this tag
//$current .= '   555:  $_SESSION[index_array_user_articles_tag] = '.$_SESSION['index_array_user_articles_tag'] ;
//file_put_contents($file, $current);	
//$current .= '   6666:  count($_SESSION[array_user_articles]  = '.count($_SESSION["array_user_articles"]) ;
//file_put_contents($file, $current);				   
                   //Definition of current_row_table - number article row in current page
//				   $_SESSION["current_row_table"] = 
//				      $_SESSION["current_article_tag"] - 
//					    ((ceil(count($_SESSION["array_user_articles_tag"])/$_SESSION['max_rows_page']) - 1) * 
//						  $_SESSION['max_rows_page']);

				   //defenition page and row of article for the tag
				   for ($i = 0; $i < count($_SESSION["array_user_articles"]); $i++)
	               {
				       if($_SESSION["array_user_articles"][$i] == $_SESSION["current_article_tag"])
					   {
					       $_SESSION['current_page'] = ceil(($i+1)/$_SESSION['max_rows_page']);
						   $_SESSION['current_row_table'] = ($i+1) - (($_SESSION['current_page'] - 1) * $_SESSION['max_rows_page']);
					   }//if
				   }//for
//$current .= '   555666: count($_SESSION[array_user_articles_tag])  = '.count($_SESSION["array_user_articles_tag"]) ;
//file_put_contents($file, $current);
//$current .= '   6666: ($_SESSION[current_row_table]  = '.$_SESSION["current_row_table"] ;
//file_put_contents($file, $current);
//$current .= '   6666: ($_SESSION[current_page]  = '.$_SESSION["current_page"] ;
//file_put_contents($file, $current);				   
			   }//if
			   
		   }//else
		   

           $rab = table_articles();//List of Articles
//$current .= '   out  search_page.php: ($_SESSION[current_page]  = '.$_SESSION["current_page"] ;
//file_put_contents($file, $current);
?>