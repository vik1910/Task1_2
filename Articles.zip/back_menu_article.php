<?php  //back_menu_article.php -  back to articles table from reading the article
          session_start();
//$file = 'DEBUGGING.txt';
//$current = file_get_contents($file);	 
		   //changing language
           include 'language.php';
	
	       // ���������� ������
           include 'config.php';
		   
		   # include my php-lib
           include 'site_php_library.php';

           $rab = table_articles();//List of Articles

?>