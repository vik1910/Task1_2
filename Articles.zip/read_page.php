<?php  //read_page.php  -  reading curent page of selected article
           session_start();
		   
//$file = 'DEBUGGING.txt';
//$current = file_get_contents($file);
//$current .= '   000: ($_SESSION[current_page]  = '.$_SESSION["current_page"] ;
//file_put_contents($file, $current); 
		   //changing language
           include 'language.php';
	
	       // ���������� ������
           include 'config.php';
		   
		   # include my php-lib
           include 'site_php_library.php';
		   
		   $current_page_read = strip_tags(substr($_POST['search_term'],0, 100));
//$current .= '   read_page.php : current_page_read  = '.$current_page_read ;
//file_put_contents($file, $current);
           $length_page = $_SESSION['n_symbols_in_row'] * $_SESSION['max_rows_page_read'];
           if($_SESSION['all_pages_read'] == 1)//there is only one page
		   {
			       $begin = 0;
				   $end = $_SESSION['n_symbols_article'];
				   $_SESSION['first_number_symbol_current_page'] = 0;
				   $_SESSION['last_number_symbol_current_page'] = $_SESSION['n_symbols_article'];
		   }//if
		   else//there are some pages
		   if($current_page_read == '+1')//next page
		   {   
		       if(($_SESSION['current_page_read'] + 1) <= $_SESSION['all_pages_read'])
			   {
		           if($_SESSION['last_number_symbol_current_page'] < $_SESSION['n_symbols_article'])
			       {
		               $_SESSION['current_page_read'] = $_SESSION['current_page_read'] + 1;
					   $_SESSION['first_number_symbol_current_page'] = 
				                $_SESSION['last_number_symbol_current_page'];
                       $begin = $_SESSION['first_number_symbol_current_page'];
			           $end = $begin + $length_page - 1;
				       if($end > $_SESSION['n_symbols_article'])
				       {$end = $_SESSION['n_symbols_article'];}//if
				       else
				       {$end = stripos($_SESSION['article_content'],' ',$end);}//else
		               $_SESSION['last_number_symbol_current_page'] = $end;
			       }//if
			   }//if
		   }
		   else 
		   if($current_page_read == '-1')//previous page
		   {
			      if($_SESSION['first_number_symbol_current_page'] > 0)
			      {
			          $_SESSION['current_page_read'] = $_SESSION['current_page_read'] - 1;
					  if($_SESSION['current_page_read'] < 1)
		                  {$_SESSION['current_page_read'] = 1;}
					  $_SESSION['last_number_symbol_current_page'] = 
					     $_SESSION['first_number_symbol_current_page'] - 1;
					  $end = $_SESSION['last_number_symbol_current_page'] - $length_page + 1;
					  $_SESSION['first_number_symbol_current_page'] = 
					         stripos($_SESSION['article_content'],' ',(-1)*$end);
				  }//if
		    }//if
			else 
            if($current_page_read == '1')
		    {
				      $_SESSION['current_page_read'] = 1;
			          $begin = 0;
				      $end = $begin + $length_page - 1;
				      if($end > $_SESSION['n_symbols_article'])
				      {$end = $_SESSION['n_symbols_article'];}//if
				      else
				      {$end = stripos($_SESSION['article_content'],' ',$end);}//else
		              $_SESSION['last_number_symbol_current_page'] = $end;
			}//if
			else //$current_page_read > 1
			{
 	            {$_SESSION['current_page_read'] = $current_page_read;}
				$begin = ($_SESSION['current_page_read'] - 1) * $length_page;
				if($begin > 0)
				{
				    $_SESSION['first_number_symbol_current_page'] = 
					         stripos($_SESSION['article_content'],' ',$begin);
				}//if
				else {$_SESSION['first_number_symbol_current_page'] = 0;}
				$end = $_SESSION['first_number_symbol_current_page'] + $length_page - 1;
				if($end > $_SESSION['n_symbols_article'])
				{$end = $_SESSION['n_symbols_article'];}//if
				else
				{$end = stripos($_SESSION['article_content'],' ',$end);}//else
		        $_SESSION['last_number_symbol_current_page'] = $end;
			}//else
//$current .= '  read_page.php : ($_SESSION[current_page_read]  = '.$_SESSION["current_page_read"] ;
//file_put_contents($file, $current);
//$current .= '  2 site_php_library.php:  $begin = '.$_SESSION['first_number_symbol_current_page'];
//file_put_contents($file, $current);			
//$current .= '  2 site_php_library.php:  $end = '.$_SESSION['last_number_symbol_current_page'];
//file_put_contents($file, $current);	
		   
		   $rab = read_article();
		   
?>