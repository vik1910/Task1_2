<?php  // content_main.php - main - Articles
	session_start();
// echo '==============';
	global $lang, $lan,  $autor_registr;
	
	//changing language
    include 'language.php';

	if (isset($_SESSION['autor_registr']))
	{
	  $autor_registr='yes';
	}
	
	$lan_PRODUCT_CATALOGUE = $lan["PRODUCT_CATALOGUE"];
	$lan_Tractors = $lan["Tractors"];
	$lan_Tanks = $lan["Tanks"];
	$lan_self_propelled_vehicles = $lan["self-propelled_vehicles"];
	$lan_Product_Search = $lan["Product_Search"];
	$lan_Find = $lan['Find'];
	$lan_AUTHORIZATION = $lan["AUTHORIZATION"];
	$lan_Input = $lan['Input'];
	$lan_REGISTRATION = $lan["REGISTRATION"];
	$lan_Registration_Form = $lan["Registration_Form"];
	$lan_Enter_the_data = $lan["Enter_the_data"];
	$lan_Login = $lan["Login"];
	$lan_Password = $lan["Password"];
	$lan_Password2 = $lan["Password2"];
	$lan_obligatory_for_input = $lan["obligatory_for_input"];
	$lan_Username_can_only_consist = $lan["Username_can_only_consist"];
	$lan_Username_must_be_at_least = $lan["Username_must_be_at_least"];
	$lan_Send = $lan['Send'];
	$lan_Please_go_to = $lan["Please_go_to"];
	$lan_Sign_in_or_Register = $lan["Sign_in_or_Register"];
	$lan_Press_OK_to_continue = $lan["Press_OK_to_continue"];
	$lan_LevelPassword = $lan["Level_Password"];
	$lan_ReInput = $lan["Re_password"];
	
	$str1 = '
			
			<div id="content_left">

				<div id="author"><h1>'.$lan_AUTHORIZATION.'</h1></div>
				<div id="authoriz1">
					
                        <div id="login1">
                            '.$lan_Login.':<br />
							<input id="login_auto" type="text" name="login_auto" value="" size="25" maxlength="30"  autofocus/>
						</div>
						<div id="password1">
							'.$lan_Password.':<br />				
							<input id="password_auto" type="password" name="password_auto" size="25" maxlength="30" value="" />
							<span><input id="Re_password_auto" type="button" name="Re_password_auto" size="25" value="'.$lan_ReInput.'" onClick="Re_password()" /></span>							
						</div>	
						<div id="submit_button1">
							<input id="button_auto" type="button" name="input_author1" size="100" value="'.$lan_Input.'" onClick="in_autoriz()" />
							<br/>
						</div>				
						<br/>
				</div>	
				<div id="messages">
					<div id="load1_auto" style="display:none;"><img src="img/load.gif" />
					</div>
					<div id="answer_auto"> 
					</div>
					<div id="answer2_auto">
					</div>
					<div id="load1_check" style="display:none;"><img src="img/load.gif" />
					</div>
					<div id="answer_check"> 
					</div>
					<div id="answer2_check">
					</div>
                </div>	
				
                   <div id="line_podch1">
						<hr width="190"  color="#b3b3b3" align="left" size="2">
				    </div>
					<div id="registration1">
						<div  id="registration" onClick="visibl_form_reg()">'.$lan_REGISTRATION.'</div>
					</div>
                    <br/>
                    <div id="line_podch1">
					   <hr width="190"  color="#b3b3b3" align="left" size="2">
				    </div>
					<div id="form_registr">
            	        
						<div id="form_registr_zag" ><center>'.$lan_Registration_Form.'</center></div>
						<div id="form_registr_main">
							
                          	    <img id="out_messages" src="img/out.jpg" width="12" height="12" onClick="out_messages1()" />				
                                <table id="table_autoriz" >
                                  <tr>
                                    <td colspan="2" height="30" cellpadding="10" >'.$lan_Enter_the_data.':</td>
                                  </tr>
                                  <tr>
								    <td  width="30" id="td1_table_autoriz">'.$lan_Login.':*</td>
                                    <td   width="70" id="td2_table_autoriz"><input id="login" type="text"  value="" size="20" maxlength="30"  name="login" onClick="form_login()"/></td>
                                  </tr>
                                  <tr>
                                	<td>'.$lan_Password.':*</td>
                                    <td><input id="password" type="password" size="20" value="" maxlength="30" name="password"  
									       onclick="form_password()" onkeyup="FLevelPassword()"/> 
									</td>
                                  </tr>
                                  <tr>
                                	<td>'.$lan_Password2.':*</td>
                                    <td><input id="password2" type="password" size="20" maxlength="30" name="password2"  
									           value=""  onclick="form_password2()" /></td>
                                  </tr>
								  <tr>
								    <td width="30">Email:*<br /></td>
                                    <td width="70"><input id="email2" type="text" size="20"  value="" name="email2" value=""  onclick="form_email2() /></td>
                                  </tr>
								  
                                  <tr>
								    <td width="30"> </td>
                                	
                                  </tr>
								  <tr>
									<td width="30">'.$lan_LevelPassword.':</td>
									<td width="70"><input id="ProcLevelPassword" type="text" name="ProcLevelPassword" size="3" maxlength="3" width="10">
									  <meter value="0" id="LevelPassword" max="100" low="100" high="60"></meter>
									</td>
								  </tr>
                                  <tr>
                                    <td  colspan="2" height="20">* - '.$lan_obligatory_for_input.'.</td>
                                  </tr>
								  <tr>
                                    <td  colspan="2" height="40">'.$lan_Username_can_only_consist.'<br/>
									                             '.$lan_Username_must_be_at_least.'<br/>
									</td>
                                  </tr>
								  <tr>
                                    <td></td>
                                    <td><pre>  </pre> </td>
                                  </tr>
                                  <tr>
                                    <td></td>
                                    <td height="30"><input id="button" type="button" name="b_form_reg" value="'.$lan_Send.'" onClick="out_form()" /></td>
                                  </tr>

                                </table>
                                <div id="load1" style="display:none;"><img src="img/load.gif" />
								</div>
								<div id="answer"> 
								</div>
								<div id="answer2">
								</div>
                            
						</div>

					</div>
			</div>
			
            <style>
			  #main {background: #dcdcdc;}
			  #catalog {background: #dcdcdc; }	  
		    </style>					
			
			<div id="forum_messages">				
					<div id="messages_err"> 
						<br/>
						<img src="img/error.png" align="left">
						<p align="center"><font color="red">'.$lan_Please_go_to.' <br/>
							'.$lan_Sign_in_or_Register.'<br/>
							'.$lan_Press_OK_to_continue.' </font></p><br/><br/>
						<div id="button_ok">
							<input  id="button_ok2" type="button"  align="middle" name="ok_forum" value="OK" onClick="out_forum_messages()" />
						</div>
					</div>
			</div>
		';	
	echo $str1;
?>			