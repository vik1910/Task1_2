<?php  //next_page.php - go to next page
          session_start();
//$file = 'DEBUGGING.txt';
//$current = file_get_contents($file);
		   
		   //changing language
           include 'language.php';
	
	       // ���������� ������
           include 'config.php';
		   
		   # include my php-lib
           include 'site_php_library.php';
		   
           $current_page = $_SESSION['current_page'];
		   $_SESSION['current_row_table']= -1; //number of selected row on current page

		   $all_pages = $_SESSION['all_pages'];
	   
		   if($current_page >= $all_pages) 
		   {
		       $current_page = $all_pages - 1;
		   }//if
		   $next_page = $current_page + 1;
		   $_SESSION['current_page'] = $next_page;
	       echo 
		   '
		     		<div id="articles_content1">
					</div>
           ';   
//	       echo '<div id="articles_content2">';
           $rab = table_articles();//List of Articles
//	       echo '</div>';
//$current .= ' next_page.php:  $_SESSION[current_page] = '.$_SESSION['current_page'];
//file_put_contents($file, $current);	
?>