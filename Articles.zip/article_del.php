<?php  //article_del.php - delete article
          session_start();
//$file = 'DEBUGGING.txt';
//$current = file_get_contents($file);	 
		   //changing language
           include 'language.php';
	
	       // ���������� ������
           include 'config.php';
		   
		   # include my php-lib
           include 'site_php_library.php';
		   
		   $current_article_id = $_SESSION['current_article_id'];
           $query = "DELETE FROM articles_tags_table WHERE article_id='$current_article_id'";
		   $query2 = mysql_query($query) or die ("<br>Invalid query: " . mysql_error()); 
           $query = "DELETE FROM articles_table WHERE article_id='$current_article_id'";
		   $query2 = mysql_query($query) or die ("<br>Invalid query: " . mysql_error()); 
//$current .= '   ajax_list_page.php:  $_SESSION[current_page] = '.$_SESSION['current_page'];
//file_put_contents($file, $current);
?>