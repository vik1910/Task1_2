<?php //save_new_tag.php - save new tag
	session_start();
//$file = 'DEBUGGING.txt';
//$current = file_get_contents($file);
	global $lang, $lan,  $autor_registr;
	
    //changing language
    include 'language.php';
	
	# ���������� ������
    include 'config.php';

	# include my php-lib
    include 'site_php_library.php';
	
	$newtag = $_GET['q'];

    $newtag = stripWhitespaces($newtag);
	$newtag  = changespace($newtag);
//$current .= ' save_new_tag.php:  newtag = '.$newtag;
//file_put_contents($file, $current);	
    if(strlen(($newtag)) > 1) 
	{
        $query = 'SELECT tag_id  FROM tags_table WHERE tag_name = '.'"'.$newtag.'"';
        $query2 = mysql_query($query);		
        $number_rows_tag = mysql_num_rows($query2);
		if($number_rows_tag == 0)
		{
		
		
		   $_SESSION['ar_tags'][count($_SESSION['ar_tags'])] = $newtag;
		}//if
    }//if
	
    $str1 = $lan["Tags"].':
			  <br />
			  '.$lan["Add_Tag"].':
			  <input id="Name_tag_auto" type="text" name="Name_tag" value="" size="30"   />
			  <input id="button_tag_add" type="button" name="tag_add" size="20" value="'.$lan["Save"].'" onClick="save_tag()" />
			  <br />
			  '.$lan["Select_Tag"].'
			  <select name="select_flag">
		   ';
	$str2 = '';
	$ar_new_tags = array();
	$k = 0;
	for ($i = 0; $i < count($_SESSION['ar_tags']); $i++)
	{
	  if($_SESSION['ar_tags'][$i] != '')
	  {
	    $ar_new_tags[$k] = $_SESSION['ar_tags'][$i];
		$k++;
	  }//if
	}//for
	for ($i = 0; $i < count($ar_new_tags); $i++)
	{

	  $str2 = $str2.'<option>'.$ar_new_tags[$i].'</option>';
	}//for
	$str3 = '</select>
	         <input id="button_tag_edit" type="button" name="tag_edit" size="20" value="'.$lan["Edit"].'" onClick="edit_tag()" />
			 <input id="button_del_tag" type="button" name="name_del_tag" size="20" value="'.$lan["Delete"].'" onClick="del_tag()" />			 
			 <br />
		  ';
	echo $str1.$str2.$str3;
?>