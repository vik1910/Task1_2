<?php  //ajax_list_page_read.php - creating pages list for reading selected article
           session_start();
//$file = 'DEBUGGING.txt';
//$current = file_get_contents($file);	 
		   //changing language
           include 'language.php';
	
	       // ���������� ������
           include 'config.php';
		   
		   # include my php-lib
           include 'site_php_library.php';
		   
           $current_page_read = $_SESSION['current_page_read'];
	   
           $str2 = '<form id="form_number_page_read" name="name_form_number_page_read"  method="post">
			            <select id="select_number_page_read" name="name_select_number_page_read" size="1"  
						        multiple="multiple" onchange="select_page_read();">';
           for ($i = 1; $i <= $_SESSION['all_pages_read']; $i++)
           {
                 $str2 = $str2.'<option value='.$i.'>'.$i.'</option>';
           }//for
           $str3 = '</select></form>';
           echo $str2.$str3;
		   $_SESSION['current_page_read'] = 0;
//$current .= '   ajax_list_page_read.php:  $_SESSION[current_page_read] = '.$_SESSION['current_page_read'];
//file_put_contents($file, $current);
?>