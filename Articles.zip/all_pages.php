<?php  // all_pages.php  -  calculation all articles pages
    session_start();
		   
//$file = 'DEBUGGING.txt';
//$current = file_get_contents($file);
//$current .= '   222:  $_SESSION[current_row_table] = '.$_SESSION['current_row_table'];
//file_put_contents($file, $current);	 
		   //changing language
           include 'language.php';
	
	       // ���������� ������
           include 'config.php';
		   
		   $max_rows_page = $_SESSION['max_rows_page'];

//$current .= '   222:  $_SESSION[current_row_table] = '.$_SESSION["current_row_table"];
//file_put_contents($file, $current);			   
		   $login_user2 = $_SESSION['login_user'];
		   $query = mysql_query("SELECT article_id, article_name, article_content, article_data, article_time  FROM `articles_table` 
	                WHERE `users_login`='".mysql_real_escape_string($login_user2)."' ");		
		   $number_rows = mysql_num_rows($query);
           if($number_rows > $max_rows_page){$_SESSION['all_pages'] = ceil($number_rows/$max_rows_page);}
		   else {$_SESSION['all_pages'] = 1;}
//$current .= '   all_pages.php:  $_SESSION[all_pages] = '.$_SESSION['all_pages'];
//file_put_contents($file, $current);		   
		   
?>