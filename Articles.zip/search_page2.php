<?php  //searche_page2.php  - searching the article by the tag
          session_start();
		   //changing language
           include 'language.php';
	
	       // include DB in config.php
           include 'config.php';
		   
		   # include my php-lib
           include 'site_php_library.php';
//$file = 'DEBUGGING.txt';
//$current = file_get_contents($file);		   
		   $_SESSION['current_tag'] = strip_tags(substr($_POST['search_term'],0, 100));
		   $search_tag = $_SESSION['current_tag'];
//$file = 'DEBUGGING.txt';
//$current = file_get_contents($file);
//$current .= '   22222222222222:  $_SESSION[current_tag] = '.$_SESSION["current_tag"];
//file_put_contents($file, $current); 

           $search_tag = stripWhitespaces($search_tag);
		   $search_tag = mysql_real_escape_string($search_tag);
		   $query = "SELECT COUNT(tag_id) FROM tags_table WHERE 
      		          tag_name="."'".$search_tag ."'"."  LIMIT 1"
//				   or die ("<br>Invalid query: " . mysql_error()); 
           $data2 = mysql_query($query);
		   if($data2) {$data = mysql_fetch_assoc(mysql_query($query)); }
		   else  {die ("<br>Invalid query: " . mysql_error());}
		   if(count($data) == 0) {echo '<br>Invalid query: ' . mysql_error();}
		   else //there is tag in DB 
		   {
		       $search_id_tag = $data['tag_id'];
//$current .= '   1:  $_search_id_tag = '.search_id_tag;
//file_put_contents($file, $current); 
               $query = "SELECT article_id FROM articles_tags_table WHERE 
      		          tag_id="."'".$search_id_tag ."'";
               $data = mysql_query($query);
			   $array_article_id = array();
			   while($data2 = mysql_fetch_assoc($data))
			   {
			       if(count($data2) > 0)
			       {$array_article_id[count($array_article_id)] = $data2['article_id'];}
			   }//while
               if(count($array_article_id) > 0)// there is article for this tag
			   {
			       for ($i = 0; $i < count($array_article_id); $i++)
	               {
			           $query = "SELECT article_id FROM articles_table WHERE 
      		                     article_id="."'".$array_article_id[$i] ."'".
								 "AND  users_login=."'".$_SESSION["login_user"]."'" ";
                       $data = mysql_query($query);
			           $_SESSION["array_user_articles_tag"] = array();
			           while($data2 = mysql_fetch_assoc($data))
			           {
			               if(count($data2) > 0)
			               {$_SESSION["array_user_articles_tag"][count($_SESSION["array_user_articles_tag"])] = 
						        $data2['article_id'];}
			           }//while
				   }//for
				   $_SESSION["current_article_tag"] = $_SESSION["array_user_articles_tag"][0];
				   //defenition page and row of article for the tag
				   for ($i = 0; $i < count($_SESSION["array_user_articles"]); $i++)
	               {
				       if($_SESSION["array_user_articles"][$i] == $_SESSION["current_article_tag"])
					   {
					       $_SESSION['current_page'] = ceil(($i+1)/$_SESSION['max_rows_page']);
						   $_SESSION['current_row_table'] = ($i+1) - (($_SESSION['current_page'] - 1) * $_SESSION['max_rows_page']);
//$current .= '   1:  $current_page = '.$_SESSION["current_page"];
//file_put_contents($file, $current); 
//$current .= '   1:  $current_row_table = '.$_SESSION["current_row_table"];
//file_put_contents($file, $current); 						   
					   }//if
				   }//for
			   }//if
			   
		   }//else
          
           $current_page = $_SESSION['current_page'];
//$current .= '   1:  $_SESSION[all_pages]= '.$_SESSION['all_pages'];
//file_put_contents($file, $current);	
//$current .= '   2:  $_SESSION[current_page]= '.$_SESSION['current_page'];
//file_put_contents($file, $current);	
		   $str2 = '<form id="form_number_page" name="name_form_number_page"  method="post"> 
			        <select id="select_number_page" name="select_page" size="1" onChange="StatusSelect();">';
	       for ($i = 1; $i <= $_SESSION['all_pages']; $i++)
	       {
			    if($_SESSION['current_page'] == $i)
			    {$str2 = $str2.'<option selected value='.$i.'>'.$i.'</option>';}
				else
	            {$str2 = $str2.'<option value='.$i.'>'.$i.'</option>';}
	       }//for
	       $str3 = '</select> </form>';
		   echo $str2.$str3;
		   
		   if($_SESSION['all_pages'] < 2)
		   {
		       echo 
			   "
			       <script>
                        $('#button_prev_page').css('display', 'none');
                   </script>
			   ";
		   }//if
		   else
		   {
		      echo 
			   "
			       <script>
                        $('#button_prev_page').css('display', 'block');
                   </script>
			   ";
		   }//else
		   

?>