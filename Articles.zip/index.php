<?php  // index.php - main contant of  Articles site
	session_start();

	global $lang, $lan,  $autor_registr, //variables for changing language
	       $login_user, //user login
	       $ar_tags, //array of all tag_name of this user for selected article
		   $ar_tag_id, //array of all tag_id of this user for selected article
		   $ar_tags_read,//array of tags for reading article
	       $n_last_tag, //last tag id 
		   $php_p, //rab
		   $max_rows_page, //max number of articles on the page
		   $max_rows_page_read, //max number of articles on the page for reading
		   $current_page, //curent page
		   $current_page_read, //curent page for reading
		   $all_pages, //all pages
		   $all_pages_read, //all pages  for reading the article 
		   $current_row_table, //number of article (from 1 to $max_rows_page) on curent page
		   $number_select_row_table,//number or selected article in all table of articles
		   $current_tag, //curent tag (user chose it)
		   $current_tag_read, //curent tag (user chose it) for reading
		   $current_article_tag, //curent article which includes curent tag
		   $array_user_articles, //all article of this user
		   $array_user_articles_tag, //array of all article of this user with this tag
		   $index_array_user_articles_tag,// curent index of array_user_articles_tag
		   $index_array_user_articles_tag_read,//curent index of array_user_articles_tag_read
		   $n_symbols_in_row, //number of symbols in the row (for reading)
		   $first_number_symbol_current_page, //number of first symbol of curent page for reading
		   $last_number_symbol_current_page, //number of last symbol of curent page for reading
		   $article_content, //all content of the article
		   $n_symbols_article,//symbols number of all content of the article
		   $n_pos_tag_in_article,//curent number of tag position in content of the article
		   $article_data_time,//time and data creating article for reading
		   $t_article_name, // article name for reading
		   $array_user_articles_tag_read, //array of all pages  with this tag for reading selected article
		   $article_URL, //  article URL
		   $current_article_id, //  current article_id
		   $id_article_read; // article id for reading
		   
	$_SESSION['max_rows_page'] = 10;//max number of rows in first page of the table
	$_SESSION['current_page'] = 0; //curent page
	$_SESSION['current_page_read'] = 1; //curent page for reading
	$_SESSION['all_pages_read'] = 0; //curent page for reading
	$_SESSION['array_user_articles_tag'] = array();//array of all article of this user with this tag
	$_SESSION['array_user_articles_tag_read'] = array();//array of all pages  with this tag for reading selected article
	$_SESSION['current_row_table']= -1; //number of selected row on current page
	$_SESSION['ar_tags'] = array();//array of tags
	$_SESSION['ar_tags_read'] = array();//array of tags for reading article
	$_SESSION['n_symbols_in_row'] = 80;//number of symbols in the row (for reading)
	$_SESSION['max_rows_page_read'] = 20;//max number of articles on the page for reading
	$_SESSION['first_number_symbol_current_page'] = 0; //number of first symbol curent page for reading
	$_SESSION['last_number_symbol_current_page'] = 0; //number of last symbol curent page for reading
	$_SESSION['login_user'] = 'xxx'; //user login
	$_SESSION['article_content'] = ''; //all content of the article
	$_SESSION['n_symbols_article'] = 0;//symbol number of all content of the article
	$_SESSION['article_data_time'] = '';//time and data creating article for reading
	$_SESSION['t_article_name'] =''; // article name for reading
	$_SESSION['id_article_read'] =''; //article id for reading
	$_SESSION['current_tag_read'] ='999'; //curent  tag searchinh page of reading article
	$_SESSION['n_pos_tag_in_article'] = 0;//curent number of tag position in content of the article
	$_SESSION['article_URL'] = '';// article URL
	
	//changing language
    include 'language.php';
	
	# plug  DB
    include 'config.php';
	
	$_SESSION['lan']=$lan;
    $lan = $_SESSION['lan'];
	
	//
	if (isset($_SESSION['autor_registr']))
	{$autor_registr='yes';}
	else { $autor_registr='no';}
	
	$p_main = '1';
	
?>

<!DOCTYPE html>
<html>
<head>
    <title><?php  echo $lan['Articles_and_Tags']; ?></title>	
	<base http://www.xxx_site.com>
	<link rel="stylesheet" type="text/css"  href="css/main.css" />	
    <script type="text/javascript" src="js/jquery-3.2.0.min.js"></script> 
	<script type="text/javascript" src="js/jquery.complexify.js"></script> 
    <script type="text/javascript" src="js/site_js_library.js"></script>	
	<meta charset="windows-1251" />
	<meta http-equiv="DESCRIPTION" content="Articles and Tags">
	<meta http-equiv="KEYWORDS" content="article, tag">
</head>
 
<body  onload="contant_main(&#34;<?php echo $p_main ?>&#34;)">
  
  <div class="wrapper">
        <div id="header_top">  
		   <center><h1><?php echo $lan["Catalog_of_Articles"] ?></h1></center>
		   <form action="forma_lang.php" method="post">		   
             <button type="submit" name="button_rus"><img id="head_flag_rus" src="img/rus.png" 
			         width="40" title="<?php echo $lan['Russian'] ?>" height="40" />
			 </button>
             <button type="submit" name="button_eng"><img id="head_flag_eng" src="img/eng.png" 
			         width="40" title="<?php echo $lan['English'] ?>" height="40" />
			 </button>        
		   </form> 			 
        </div> 
<!--	menu: Articles, Tags 	
        <div id="header_bottom">		
            <SPAN id="main"> 
   				 <SPAN><style>#main {background: #d0c3b2;}</style></SPAN><?php echo $lan["Main"] ?>
			</SPAN>
			<SPAN id="tags"    onClick="forum('1')"><?php echo $lan["Tags"] ?></SPAN>
   		    <hr/>	
        </div>
 -->
        <div id="content_main1">	<!-- rab --> 	
	    </div>
		
		<div id="content_main">		<!-- rab -->   
	    </div>
		
        <div id="content_main11">	<!-- for forms of article -->	
	    </div>
		
		<div id="content_main2"> <!-- for content of articles -->
	    </div>
		
		<div id="content_main3">	<!-- for buttons and forms-->		 	
             <div id="select_page"></div> 
			     <form id="searchform" name="name_searchform" method="post">
					  <input id="button_prev_page" type="button" name="name_prev_page" size="100" 
					         value=<?php echo $lan["prev_page"] ?>  />
					  <input id="button_next_page" type="button" name="name_next_page" size="100" 
					         value=<?php echo $lan["next_page"]?>  />
                      <SPAN id="many_pages"><?php echo $lan["Page"]?></SPAN> 
					  <input  id="button_article_search" type="button"  align="middle" name="ok_article_search" size="130" 
					         value=<?php echo $lan["Search"] ?> /> 
					  <input  id="button_article_add" type="button"  align="middle" name="ok_article_add" size="100" 
					         value=<?php echo $lan["Add"] ?> onClick="article_add()"/>
					  <input id="read_page" type="button" name="name_read_page" size="100" 
					         value=<?php echo $lan["read_page"] ?> /> 
					  <input  id="button_article_edit" type="button"  align="middle" name="ok_article_edit" size="100"
					         value=<?php echo $lan["Edit"] ?> />
					  <input  id="button_article_del" type="button"  align="middle" name="ok_article_del" size="100"
          				     value=<?php echo $lan["Delete"] ?> onClick="article_del()">
                      <SPAN id="search_article"></SPAN>							 
                 </form> 	
				 
                 <!-- Form for reading selected article  -->
				 <div id="select_page_read"></div> 
				 <div id="search_article_read"></div>
				 <form id="searchform_read" method="post">
				      <input id="button_prev_page_read" type="button" name="name_prev_page_read" size="100" 
					         value=<?php echo $lan["prev_page"] ?>  />	
					  <input id="button_next_page_read" type="button" name="name_next_page_read" size="100" 
					         value=<?php echo $lan["next_page"]?>  />
                      <SPAN id="many_pages_read"><?php echo $lan["Page"]?></SPAN> 
					  <input  id="button_article_search_read" type="button"  align="middle" name="ok_article_search_read" size="130" 
					         value=<?php echo $lan["Search"] ?> />
					  <input  id="back_menu_article" type="button"  align="middle" name="name_back_menu_article" size="100" 
					         value=<?php echo $lan["Back"] ?> />
							 
                 </form> 
				 
	    </div>
		
 		<div id="menu_bottom">	<!-- rab --> 
		</div>
        
        <div id="footer">
			<div id="copyright1">
				<center>Copyright &#169 - <?php echo $lan["Articles_and_Tags"] ?></center>
			</div>
			<div id="designer"> <!-- rab --> 
			</div>        
        </div>	            
  </div>
</body>
</html>