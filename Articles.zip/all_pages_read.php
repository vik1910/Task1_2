<?php  // all_pages_read.php  -  calculation all articles pages  for reading the selected article 
           session_start();
//$file = 'DEBUGGING.txt';
//$current = file_get_contents($file);
 
		   //changing language
           include 'language.php';
	
	       // ���������� ������
           include 'config.php';
		   
           $current_page = $_SESSION['current_page'];
		   $max_rows_page = $_SESSION['max_rows_page'];
		   
//$current .= '   all_pages_read.php:  $current_page = '.$current_page;
//file_put_contents($file, $current);
//$current .= '   all_pages_read.php:  $_SESSION[current_row_table] = '.$_SESSION["current_row_table"];
//file_put_contents($file, $current);	
		   
           //finding article_id for reading		   
		   $login_user2 = $_SESSION['login_user'];
		   $query = mysql_query("SELECT article_id, article_name, article_content, article_data, article_time  FROM `articles_table` 
	                WHERE `users_login`='".mysql_real_escape_string($login_user2)."' ");		
		   $number_rows = mysql_num_rows($query);
		   if($number_rows > 0)//there are articles of this user
		   {
               $n_row_article = (($current_page - 1) * $max_rows_page) + $_SESSION["current_row_table"] - 1;
//$current .= '   222:  $n_row_article = '.$n_row_article;
//file_put_contents($file, $current);	
//$current .= '   222:  $number_rows = '.$number_rows;
//file_put_contents($file, $current);		   		   
		       for($i = 0; $i < $number_rows; $i++)
		       {
		           $data = mysql_fetch_assoc($query);
		           if($i == $n_row_article) //FOR SELECTED ARTICLE
			       {
//$current .= '   222:  $i = '.$i;
//file_put_contents($file, $current);
			           $_SESSION['t_article_name'] = $data['article_name']; // article name for reading
//$current .= '   222:  $_SESSION[t_article_name] = '.$_SESSION["t_article_name"];
//file_put_contents($file, $current);				   
				       $_SESSION['article_content'] = $data["article_content"]; //all content of the article
					   
				       $_SESSION['n_symbols_article'] = strlen($_SESSION['article_content']);//symbols number of all content of the article
					   $_SESSION['id_article_read'] = $data['article_id'];
			           $article_data = $data['article_data'];
			           $article_time = $data['article_time'];
				       $_SESSION['article_data_time'] =  $article_data.' '.$article_time;
					   $_SESSION['current_tag_read'] ='999';
					   
					   //definition page number of the article
					   $_SESSION['all_pages_read'] = 
					      ceil($_SESSION['n_symbols_article']/$_SESSION['n_symbols_in_row']/$_SESSION['max_rows_page_read']);
						  
					   //defenite names array of tags for only one article of this user
					   $_SESSION['ar_tags'] = array(); //tag_name array for selected article
					   $_SESSION['ar_tag_id'] = array(); //tag_id array for selected article
					   
	                   $data_article_id = $_SESSION['id_article_read'];
//$current .= '   all_pages_read.php:  data_article_id  = '.$data_article_id;
//file_put_contents($file, $current);	
		               $query2 = "SELECT tag_id  FROM articles_tags_table WHERE article_id ="."'".$data_article_id."'";
		               $data3 = mysql_query($query2);
		               while($data4 = mysql_fetch_assoc($data3))
	                   {
		                 $flag_tag = true;
		                 for ($k = 0; $k < count($_SESSION['ar_tag_id']); $k++)
	                     {	
			                 if($_SESSION['ar_tag_id'][$k] == $data4["tag_id"]) {$flag_tag = false;}
			             }//for
		                 if($flag_tag) 
			             {
			                 $_SESSION['ar_tag_id'][count($_SESSION['ar_tag_id'])] = $data4["tag_id"];	
			             }//if
		               }//while
					   if(count($_SESSION['ar_tag_id']) > 0) 
					   (
					       for ($k = 0; $k < count($_SESSION['ar_tag_id']); $k++)
	                       {	
			                   $query = "SELECT tag_name  FROM articles_tags_table WHERE tag_id ="."'".$_SESSION['ar_tag_id'][k]."'";
		                       $data2 = mysql_query($query);
							   $number_rows = mysql_num_rows($query2);
		                       if($number_rows > 0)
		                       {
							       $_SESSION['ar_tags'][count($_SESSION['ar_tags'])] =  $data2["tag_name"]; 
//$current .= '   all_pages_read.php:  $_SESSION[ar_tags][k]  = '.$_SESSION['ar_tags'][k];
//file_put_contents($file, $current);								   
							   }//if
			               }//for
					   )//if
			        }//if
		       }//for
		   }//if	   
//$current .= '   all_pages_read.php:  $_SESSION[all_pages_read] = '.$_SESSION["all_pages_read"];
//file_put_contents($file, $current);  
//$current .= '   all_pages_read.php:  $_SESSION[article_content] = '.$_SESSION["article_content"];
//file_put_contents($file, $current);
?>