<?php  //f_read_page.php - imaging selected article in list of articles
          session_start();
		 
		   //changing language
           include 'language.php';
	
	       // ���������� ������
           include 'config.php';
		   
		   # include my php-lib
           include 'site_php_library.php';
		   
		   //number_select_row_table (on current page, calculating all rows of articles)
		   
	       $_SESSION['current_row_table'] = strip_tags(substr($_POST['search_term'],0, 100));
		   $current_page = $_SESSION["current_page"] ;
//$file = 'DEBUGGING.txt';
//$current = file_get_contents($file);
//$current .= '   f_read_page.php: ($_SESSION[current_row_table]  = '.$_SESSION["current_row_table"] ;
//file_put_contents($file, $current);
//$current .= '   f_read_page.php: ($_SESSION[current_page]  = '.$_SESSION["current_page"] ;
//file_put_contents($file, $current);  
	   
		   //finding article_id for reading		   
		   $login_user2 = $_SESSION['login_user'];
		   $query = mysql_query("SELECT article_id, article_name, article_content, article_data, article_time  FROM `articles_table` 
	                WHERE `users_login`='".mysql_real_escape_string($login_user2)."' ");		
		   $number_rows = mysql_num_rows($query);
		   if($number_rows > 0)//there are articles of this user
		   {
               $n_row_article = (($current_page - 1) * $max_rows_page) + $_SESSION["current_row_table"] - 1;
//$current .= '   222:  $n_row_article = '.$n_row_article;
//file_put_contents($file, $current);	
//$current .= '   222:  $number_rows = '.$number_rows;
//file_put_contents($file, $current);		   		   
		       for($i = 0; $i < $number_rows; $i++)
		       {
		           $data = mysql_fetch_assoc($query);
		           if($i == $n_row_article) //FOR SELECTED ARTICLE
			       {
//$current .= '   222:  $i = '.$i;
//file_put_contents($file, $current);
			           $_SESSION['t_article_name'] = $data['article_name']; // article name for reading
//$current .= '   222:  $_SESSION[t_article_name] = '.$_SESSION["t_article_name"];
//file_put_contents($file, $current);				   
				       $_SESSION['article_content'] = $data["article_content"]; //all content of the article					   
				       $_SESSION['n_symbols_article'] = strlen($_SESSION['article_content']);//symbols number of all content of the article
					   $_SESSION['id_article_read'] = $data['article_id'];
					   $_SESSION['current_article_id'] = $data['article_id'];
			           $article_data = $data['article_data'];
			           $article_time = $data['article_time'];
				       $_SESSION['article_data_time'] =  $article_data.' '.$article_time;	  
			        }//if
		       }//for
		   }//if
		   
           $rab = table_articles();//List of Articles
?>