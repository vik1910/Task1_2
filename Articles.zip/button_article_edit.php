<?php  // button_article_edit.php - form for editing selected article
//$file = 'DEBUGGING.txt';
//$current = file_get_contents($file);
	session_start();
// echo '==============';
	global $lang, $lan,  $autor_registr;
	
	////changing language
    include 'language.php';
	
	# ���������� ������
    include 'config.php';
	
	$current_page = $_SESSION['current_page'];
	$max_rows_page = $_SESSION['max_rows_page'];
		   
//$current .= '   button_article_edit.php:  $current_page = '.$current_page;
//file_put_contents($file, $current);
//$current .= '   button_article_edit.php:  $_SESSION[current_row_table] = '.$_SESSION["current_row_table"];
//file_put_contents($file, $current);	
		   
    //finding article_id for reading		   
	$login_user2 = $_SESSION['login_user'];
	$query = mysql_query("SELECT article_id, article_name, article_content, article_data, article_time  FROM `articles_table` 
	                      WHERE `users_login`='".mysql_real_escape_string($login_user2)."' ");		
    $number_rows = mysql_num_rows($query);
    if($number_rows > 0)//there are articles of this user
	{
        $n_row_article = (($current_page - 1) * $max_rows_page) + $_SESSION["current_row_table"] - 1;
//$current .= '   222:  $n_row_article = '.$n_row_article;
//file_put_contents($file, $current);	
//$current .= '   222:  $number_rows = '.$number_rows;
//file_put_contents($file, $current);		   		   
		for($i = 0; $i < $number_rows; $i++)
		{
		    $data = mysql_fetch_assoc($query);
		    if($i == $n_row_article)
			{
//$current .= '   222:  $i = '.$i;
//file_put_contents($file, $current);
			    $_SESSION['t_article_name'] = $data['article_name']; // article name for reading
//$current .= '   222:  $_SESSION[t_article_name] = '.$_SESSION["t_article_name"];
//file_put_contents($file, $current);				   
				$_SESSION['article_content'] = $data["article_content"]; //all content of the article
					   
			    $_SESSION['n_symbols_article'] = strlen($_SESSION['article_content']);//symbols number of all content of the article
			    $_SESSION['id_article_read'] = $data['article_id'];
			    $article_data = $data['article_data'];
			    $article_time = $data['article_time'];
				$_SESSION['article_data_time'] =  $article_data.' '.$article_time;
			    $_SESSION['current_tag_read'] ='999';
				$_SESSION['article_URL'] =  $data['article_URL']; //article_URLt of the article
				if($_SESSION['article_URL'] == null) $_SESSION['article_URL'] = '';
//$current .= '   button_article_edit.php:  $_SESSION[article_URL] = '.$_SESSION['article_URL'];
//file_put_contents($file, $current);						   
			    //definition page number of the article
				$_SESSION['all_pages_read'] = 
				    ceil($_SESSION['n_symbols_article']/$_SESSION['n_symbols_in_row']/$_SESSION['max_rows_page_read']);
					   
			}//if
		}//for
    }//if	   
		
//	$_SESSION['current_page'] //curent page
//  $_SESSION['current_row_table'] //number of selected row on current page
	//form for adding article
			 echo '
                  <style>
				      #forma_article{
                          display: block;
					  } 
				  </style>
		      ';
	echo '
	         <form id="forma_article" name="forma_add_article"  method="post" action="">
			    <div id="title_forma_article"><h1>'.$lan["Forma_for_editing_article"].'</h1></div>
			    <div id="Name_article">
                            '.$lan["Name_article"].':<br />
							<input id="Name_article_auto" type="text" name="Name_article" value='.$_SESSION["t_article_name"].' size="135" maxlength="100"  autofocus/>
				</div>
				<div id="Content_article">
                            '.$lan["Text_article"].':<br />
							<textarea rows="20" cols="125" name="text_form_article" wrap="soft">'.$_SESSION["article_content"].'						
							</textarea> 							
				</div>
				<div id="bl_URL_adress">
				  '.$lan["URL_adress"].':<br />
					<input id="st_URL_adress" type="text" name="name_URL_adress"
		 ';
	echo 		'value =""';
	echo
		'       size="128" maxlength="200" />
				</div>
				<div id="Article_Tags">
				  '.$lan["Tags"].':
			      <br />
			      '.$lan["Add_Tag"].':
			      <input id="Name_tag_auto" type="text" name="Name_tag" value="" size="30"   />
			      <input id="button_tag_add" type="button" name="tag_add" size="20" value="'.$lan["Save"].'" onClick="save_tag()" />
			      <br />
				</div>
  				<input id="button_submit_tag" type="button" name="name_submit_tag" size="100" value="'.$lan["Save"].'" onClick="edit_data_form_a()" />			 
				<input id="button_cancel_tag" type="button" name="name_cancel_tag" size="100" value="'.$lan["cancel"].'" onClick="cancel_form_a()" />			 
			 </form>
	    ';
?>