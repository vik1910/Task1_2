<?php  //search_page_read.php - searching first and next page  with this tag in the slected article for reading
          session_start();

		   //changing language
           include 'language.php';
	
	       // ���������� ������
           include 'config.php';
		   
		   # include my php-lib
           include 'site_php_library.php';
//$file = 'DEBUGGING.txt';
//$current = file_get_contents($file);
	       $login_user = $_SESSION["login_user"];
		   $rab_next = strip_tags(substr($_POST['search_term'],0, 100));//selected tag for reading
//$current .= '   search_page_read.php   rab_next = '.$rab_next;
//file_put_contents($file, $current);		   
		   if($rab_next != '^^^') //it is  thirst call of searching by this tag
		   {
		       $_SESSION['current_tag_read'] = $rab_next;
               $_SESSION['n_pos_tag_in_article'] = 
			      stripos($_SESSION['article_content'], $_SESSION['current_tag_read'] );
		   }//if
           else //it is not  thirst call of searching by this tag
		   {		   
		       $_SESSION['n_pos_tag_in_article'] = 
			     strrpos($_SESSION['article_content'], $_SESSION['current_tag_read'],
				   $_SESSION['n_pos_tag_in_article'] + 1);	
		   }//else
		   if($_SESSION['n_pos_tag_in_article'] < 0) $_SESSION['n_pos_tag_in_article'] = 0;
		   
//$current .= '   out  search_page_read.php: ($_SESSION[n_pos_tag_in_article]  = '.$_SESSION["n_pos_tag_in_article"] ;
//file_put_contents($file, $current);
           //definition page number of the article whith $_SESSION['n_pos_tag_in_article'] 
					   $_SESSION['current_page_read'] = 
					      ceil($_SESSION['n_pos_tag_in_article']/$_SESSION['n_symbols_in_row']/$_SESSION['max_rows_page_read']);
//$current .= '   out  search_page.php: ($_SESSION[current_page_read]  = '.$_SESSION["current_page_read"] ;
//file_put_contents($file, $current);						  
						  
           $rab = read_article();//page of content for reading selected article

?>