<?php  //go to prev. page
          session_start();
//echo "=============������� ����� - ".date("H:i:s");		   
//echo "= "." ";		 
		   //changing language
           include 'language.php';
	
	       // include DB in config.php
           include 'config.php';
		   
		   # include my php-lib
           include 'site_php_library.php';
//$file = 'DEBUGGING.txt';
//$current = file_get_contents($file);		   
		   $_SESSION['current_page'] = strip_tags(substr($_POST['search_term'],0, 100));

           $current_page = $_SESSION['current_page'];
//$current .= '   1:  $_SESSION[all_pages]= '.$_SESSION['all_pages'];
//file_put_contents($file, $current);	
//$current .= '   2:  $_SESSION[current_page]= '.$_SESSION['current_page'];
//file_put_contents($file, $current);	
		   $str2 = '<form id="form_number_page" name="name_form_number_page"  method="post"> 
			        <select id="select_number_page" name="select_page" size="1" onChange="StatusSelect();">';
	       for ($i = 1; $i <= $_SESSION['all_pages']; $i++)
	       {
			    if($_SESSION['current_page'] == $i)
			    {$str2 = $str2.'<option selected value='.$i.'>'.$i.'</option>';}
				else
	            {$str2 = $str2.'<option value='.$i.'>'.$i.'</option>';}
	       }//for
	       $str3 = '</select> </form>';
		   echo $str2.$str3;
		   
		   if($_SESSION['all_pages'] < 2)
		   {
		       echo 
			   "
			       <script>
                        $('#button_prev_page').css('display', 'none');
                   </script>
			   ";
		   }//if
		   else
		   {
		      echo 
			   "
			       <script>
                        $('#button_prev_page').css('display', 'block');
                   </script>
			   ";
		   }//else
		   

?>