<?php
//•conf.php — Файл конфигурации, в котором так же содержится подключение к бд;

global $link, $dbname;

$_SESSION['dbname'] = 'articles_BD';
$dbname = $_SESSION['dbname'];

// $cfg['Servers'][$i][$dbname] = null;

# настройки
define ('DB_HOST', 'localhost');
define ('DB_LOGIN', 'root');
define ('DB_PASSWORD', '');
define ('DB_NAME', 'articles_BD');
$dbname = 'articles_BD'; 	// name of DB
$link=mysql_connect(DB_HOST, DB_LOGIN, DB_PASSWORD) or die ("MySQL Error: " . mysql_error());
mysql_query("set names cp1251") or die ("<br>Invalid query: " . mysql_error());
mysql_select_db(DB_NAME) or die ("<br>Invalid query: " . mysql_error());

$_SESSION['link']=$link;

# массив ошибок
$error[0] = 'Я вас не знаю';
$error[1] = 'Включи куки';
$error[2] = 'Вам сюда нельзя';

	
?> 