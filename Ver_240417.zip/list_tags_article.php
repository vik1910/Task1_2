<?php 
	session_start();
//echo '==============';
	
    //changing language
    include 'language.php';
	
	# include DB in config.php
    include 'config.php';
	
	# include my php-lib
    include 'site_php_library.php';
//$file = 'DEBUGGING.txt';
//$current = file_get_contents($file);

	$number_rows_tag = array();
	$login_user = $_SESSION['login_user'];
	$query = "SELECT article_id  FROM articles_table WHERE users_login ="."'".$login_user."'";
	$data = mysql_query($query);
	while($data2 = mysql_fetch_assoc($data))
	{
	    $data_article_id = $data2["article_id"];
//$current .= '   1:  $data_article_id = '.$data_article_id;
//file_put_contents($file, $current);	
	    $data_article_id = stripWhitespaces($data_article_id);
 	    $data_article_id = mysql_real_escape_string($data_article_id);
		$query2 = "SELECT tag_id  FROM articles_tags_table WHERE article_id ="."'".$data_article_id."'";
		$data3 = mysql_query($query2);
	
		while($data4 = mysql_fetch_assoc($data3))
	    {
		     $number_rows_tag[count($number_rows_tag)] = $data4["tag_id"];
		}//wile
	}//while

    if(count($number_rows_tag) > 0)//there are tags
    {		
        $str2 = '<form id="form_search_article" name="name_form_search_article"  method="post">
                 <select id="search_number_article" name="search_article" size="1" onChange="StatusSearch();">';
		for ($k = 0; $k < count($number_rows_tag); $k++)
	    {
		    $query = "SELECT  tag_name FROM tags_table WHERE tag_id="."'".$number_rows_tag[$k]."'"." ORDER BY tag_name";
	        $query2 = mysql_query($query);
			$data2 = mysql_fetch_assoc($query2);
			$article_tag_name = $data2['tag_name'];
            $str2 = $str2.'<option  value='.$article_tag_name.'>'.$article_tag_name.'</option>';
		}//for
		echo $str2.'</select></form>';
	}//if
	
?>