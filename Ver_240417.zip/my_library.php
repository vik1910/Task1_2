<?php   

	session_start();
	
    # ���������� ������
    include 'config.php';
	
	// last_id - return id  last record in table
    function last_id($table, $id_column) 
	{
      if ($table && $id_column) 
	  {
        if (mysql_table_seek($table, $dbname))
		{
		  $query = "SELECT * FROM ".(string)$table;
		
          $f_result = mysql_query($query);
		  if ($f_result)
		  {
		    $id_last_zap = 0;
            while ($stuff = mysql_fetch_assoc($f_result)) 
		    { $id_last_zap = $stuff[$id_column];}		
            return $id_last_zap;
		  } else {return false;}
		} else {return false;}
      } else {return false;}
    } // last_id($table, $id_column)
	
	// mysql_table_seek - YES or NO table in DB
	function mysql_table_seek($tablename, $dbname)
	{
	  $query = "SELECT 1 FROM ".$tablename." WHERE 0" ;
      $rslt = mysql_query($query);
      if ($rslt) {return true;}
	  else {return false;}
    } //   mysql_table_seek($tablename, $dbname)

	
	// calculate all records in tablename
	function calc_all_records($tablename, $dbname) 
    { 
	  $kol_zap = 0; // number of records
	  if (mysql_table_seek($tablename, $dbname) )
	  {
	     $kol_zap = 0; // number of records
	     $query = "SELECT * FROM " . $tablename;
		 $result2 = mysql_query($query) or die("Invalid query: " . mysql_error());
		 while ($row = mysql_fetch_assoc($result2)) 
		{
			$kol_zap = $kol_zap + 1; 
        }
		mysql_free_result($result2);
	  }
	  else	echo 'Not exist table ' . $tablename;
	  return $kol_zap;
    } //	function  calc_all_records

//	  $Theme_name_answer = search_records('Theme_Rules', 'Theme_id', $id_current_theme, 'Theme_name_answer', $dbname); 

 
	// search field out_field in tablename by id_field
	function search_records($tablename, $id_tablename, $id_field, $out_field, $dbname) 
    { 
	  $return_out_field = '';
		  
	  if (mysql_table_seek($tablename, $dbname))
	  { 
	    $query = "SELECT " . $out_field . " FROM " . $tablename . " WHERE " . (string)$id_tablename . "=" . (string)$id_field;						
//echo '$query='.$query;		
		$result5 = mysql_query($query) or die("Invalid query: " . mysql_error());		
		while ($row5 = mysql_fetch_assoc($result5)) 
		{				
 			  $return_out_field = $row5[$out_field];
        }
		mysql_free_result($result5);		  
      } // if
	  else // table tablename exist but no any records
	  {
	    $theme_user_login = '';
	  }
	  return $return_out_field;
	} // function search_records
	
	// trim_2_param(str,par1,par2) - trim str for 2 parametrs - par1, par2
	function trim_2_param($str,&$par1,&$par2)
	{
   	 $str = trim($str); // delete spaces
	 $l_str = strlen($str);
//echo '$str = '.$str;	 
	 if($l_str>0)
	 {
	   $sh_pos = strpos($str,'^');
//echo '$sh_pos = '.$sh_pos;	   
	   if($sh_pos > 1)
	   {
//	echo 'str='.$str.' $sh_pos='.$sh_pos;
  	     $par1 = substr($str,0,$sh_pos);  
	     $par2 = substr($str,$sh_pos+1,$l_str);  
	     return true;
	   } // if
	   else {return false;}
	  }
	  else return false;
	} //  trim_2_param()
	
	// convertion format date: from yy.mm.dd to dd.mm.yy
	function Time_To_UKR($value)
	{
	  if (strripos($value,'-'))
	  {$date_elements  = explode("-",$value);
	   return $date_elements[2].'.'.$date_elements[1].'.'.$date_elements[0]; // dd.mm.yy
	  } // if
	  else {if (strripos($value,'.'))
	        {$date_elements  = explode(".",$value);
			  return $date_elements[2].'.'.$date_elements[1].'.'.$date_elements[0]; // dd.mm.yy
			}
		    else return $value;
	  } // else
	} // function Time_To_Show($value)
	
?>