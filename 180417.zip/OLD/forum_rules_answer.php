<?php
// forum_rules_answer.php - list of Themes for Rules  

	session_start();

    $login = $_SESSION['login'];
	
	$name_answer4 = iconv("UTF-8", "Windows-1251", $_GET['name_Theme2']);

	$n_section = $_SESSION['n_section'];
//echo '$n_section='.$n_section;	

	// name of answer file 
	$q=$_GET['q'];
//echo '$q='.$q;	
	// Get name_Theme2 and n_section
//	if (!trim_2_param($str,$q,$n_section))
//	{echo "name_Theme is't correct!";}
    $_SESSION['Theme_name_answer'] = $q;

    # ���������� ������
    include 'config.php';
	
	# Load my library
    include 'my_library.php';
	
	// setting the language 
	if (isset($_SESSION['lang2']))
	{
	  if ($_SESSION['lang2'] == 'eng')
		{
			$lang = 'eng';
		}
		{
			$lang = 'rus';
		}
	}
	else
	{
		$_SESSION['lang2']='rus';	
		$lang = 'rus';
	}
	
	$lan = $_SESSION['lan'];		

	// writing in HTML	
	$lan_Add_Record=$lan["Add_Record"];	
		
	switch ($n_section) {
    case '1':
        $file_Theme = 'Theme_Rules';		
		$file_answer = 'Theme_Rules';
		$tablename = 'theme_rules_'.$q;
        break;
    case '2':
        $file_Theme = 'Theme_manufacturer';
		$file_answer = 'Theme_manuf';
		$tablename = 'Theme_manuf_'.$q;
        break;
    case '3':
        $file_Theme = 'Conferences';
		$file_answer = 'Conferences';
		$tablename = 'Conferences_'.$q;
        break;	
    case '4':
        $file_Theme = 'Ta_Database';
		$file_answer = 'Ta_Database';
		$tablename = 'Ta_Database_'.$q;
        break;	
    case '5':
        $file_Theme = 'Tan_Reviews';
		$file_answer = 'Tan_Reviews';
		$tablename = 'Tan_Reviews_'.$q;
        break;	
    case '6':
        $file_Theme = 'Tr_Database';
		$file_answer = 'Tr_Database';
		$tablename = 'Tr_Database_'.$q;
        break;	    
    case '7':
        $file_Theme = 'Tra_Reviews';
		$file_answer = 'Tra_Reviews';
		$tablename = 'Tra_Reviews_'.$q;
        break;	    
    case '8':
        $file_Theme = 'Shoppingdoc';
		$file_answer = 'Shoppingdoc';
		$tablename = 'Shoppingdoc_'.$q;
        break;	    
	case '9':
        $file_Theme = 'Shopping_3D';
		$file_answer = 'Shopping_3D';
		$tablename = 'Shopping_3D_'.$q;
        break;					
    }  //  switch   
	
	// Reading answers from table $name_answer3 and writing in HTML
//    $tablename = $q;	 // table of answer file
	
    if (mysql_table_seek($tablename, $dbname))
	{
	  if ($link)
	  {		
	    $query = "SELECT * FROM " . $tablename;
		$result = mysql_query($query ) or die("Invalid query: " . mysql_error());
	  }	// if	 
	  
	  $sch = 0; // number records in table tablename
      while ($row2 = mysql_fetch_array($result, MYSQL_BOTH)) 
	  {   
 	    $sch = $sch + 1;
		
	    // reading id from table tablename
		$Theme_Rules_x_user_id = $row2['Theme_Rules_x_user_id'];
	  
		 // reading login author of theme
		$users_login_author_theme = search_records('users', 'users_id', $Theme_Rules_x_user_id, 'users_login', $dbname);
		  
		// reading name of Theme
		$name_theme = search_records($file_Theme, 'Theme_id', $row2['Theme_Rules_Theme_id'], 'Theme_text', $dbname);
				
		// reading login author of answer
		$users_login_author_answer = search_records('users', 'users_id', $row2['Theme_Rules_x_user_id'], 'users_login', $dbname);

		// reading data, time of theme
		$data_theme = Time_To_UKR(search_records($file_Theme, 'Theme_id', $row2['Theme_Rules_Theme_id'], 'Theme_data', $dbname));
		$time_theme = search_records($file_Theme, 'Theme_id', $row2['Theme_Rules_Theme_id'], 'Theme_time', $dbname);

		// reading data, time of answer
		$data_answer = Time_To_UKR($row2['Theme_Rules_data']);	
		$time_answer=$row2['Theme_Rules_time'];
		
		// reading  answer
		$text_answer = $row2['Theme_Rules_text'];			
		
        $lan_Enter_new_Record = $lan["Enter_new_Record"];
		$lan_Enter_new_Record600 = $lan["Enter_new_Record600"];

		// for first records
		if ($sch == 1)
		{
		  $str3 = '<div id="rab0404">
				<style> #rab0404 {background: #696969;
						  color: white;
				}</style>
			&nbsp;'.$lan["Theme"].':&nbsp;
			'.$text_answer.'
			&emsp;&emsp;'.$lan["Author"].':&nbsp;'
			.$users_login_author_theme.'&emsp;&emsp;
			'.$lan["Date"].':&nbsp;'.$data_answer.'
		  </div></br>

		  <div id="forma_Record">

			<div id="forma_Record_txt">
				'.$lan_Enter_new_Record.':* <br/>
			</div>		
			<div id="name_Record">			
			  <textarea id="name_Record2" name="name_Record3"
			       cols="120" rows="5" wrap="off" autofocus></textarea><br>
			</div>	
			<div id="button_record1_txt">
			   *'.$lan_Enter_new_Record600.'
			</div>			
			<div id="button_record_rules1">
			    <input  id="button" type="button" name="OK_Record" value="OK" onClick="OK_Add_Record('.$n_section.')" /><br/>
		    </div>	  	
		  </div> 		  
		  ';	  
		  echo  $str3;	
		    
		}  // if
		else
		{
		  $_SESSION["id_current_theme"]=$row2['Theme_Rules_Theme_id'];	
          $str1 = '<div id="rab0604"> 
		             <style> #rab0604 {
						  color: #d8860b;;
				     }</style>
				     &nbsp;'.$lan["Record_from"].':&emsp; 
			         '.$users_login_author_answer.'&emsp;&emsp;
				     '.$data_answer.'&emsp;&emsp;
				     '.$time_answer.'&emsp;</br>
				   </div>
					 <hr width="500"  color="#696969" align="left" size="2" />
		             &emsp;'.$text_answer.'
					 <hr width="1000"  color="#696969" align="left" size="2" />		
		  ';

				
          echo  $str1;
        }		
      }  //while 
	}  //if	  
	$str2 = '<spacer  width="500"></spacer>
	         <div id="button_Add_Record">
			 <input  id="#button_Add_Record" type="button" name="Add_Record" value="'.$lan_Add_Record.'" onClick="Add_Record()" />
		     </div>					   		   
			   ';
	echo  $str2;
	$lan_back_record=$lan["Back_Record"];
	$str3 = '<spacer  width="10"></spacer>
			 <div id="button_back_record">
			 <input  id="#button_back_record2" type="button" name="back_record" value="'.$lan_back_record.'" onClick="Back_Record('.$n_section.')" />
		     </div>					   		   
			   ';
	echo  $str3;

//	else echo 'Not exist table ' . $name_theme_answer;
	
?>