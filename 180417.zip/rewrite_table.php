<?php
  include 'php_library.php';
  
echo '7777777777';

    $rab = table_articles();
	
?>
