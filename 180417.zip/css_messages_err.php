<?php
	echo '<style>
 #forum_messages{
   position: absolute;
    width: 330px;
    height: 300px;
    left: 228px;
    top: 4px; 
    background-color: #eff0f4;
    border: 1px solid #dcdcdc; 
    visibility: visible;
    z-index: 120;
	box-shadow: 0 0 10px rgba(0,0,0,0.5); 
}
#messages_err{
	font-size: 150%;
	color: red;
	visibility: visible;
}
</style>';

	
?>