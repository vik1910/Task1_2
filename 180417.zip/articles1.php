<?php
// articles1.php � main menu of Articles
//phpinfo();
  session_start();
	
  # ���������� ������
  include 'config.php';
	 
  $p_main = '2';
  
  //changing language
  include 'language.php';

  include  'site_php_library.php';//php-lib of the site
	
//echo '$lan ='.$lan['Articles_and_Tags'];
  // set DB
  $dbname = $_SESSION['dbname'];
  $link = $_SESSION['link'];	
	
  // $autor_registr = 'yes' - there is registration
  $login_user2 = $_SESSION['login_user'];
//echo "login_user2 = ".$login_user2;	

  // get name table for answer
  $q=$_GET['q'];
  
  $lan_go_to_registration = $lan['go_to_registration'];
  $lan_Press_OK_to_continue = $lan['Press_OK_to_continue'];
  $lan_confirm_your_Registration = $lan['confirm_your_Registration'];
  $lan_n_o_registred_user = $lan['n_o_registred_user'];
  
  if($login_user2 != '') //Login wasn't inputed
  {
    # Read from DB (with login_user2) 
    $data = mysql_fetch_assoc(mysql_query("SELECT users_id, users_password, users_status  FROM `users` 
	      WHERE `users_login`='".mysql_real_escape_string($login_user2)."' LIMIT 1")); 
    if(count($data) > 0) //Login was found
    {
      if($data['users_status'] == 0) //there is not confirm your Registration
	  {
	    echo '
	         <style>
               #content_main {visibility:  visible; }
             </style>;
	         <div id="content_main">
		          <br/>
                  <img src="img/error.png" align="left">
		          <p align="left"><font color="red" font-size="20pt">'.$lan_confirm_your_Registration.'<br/>
		          '.$lan_Press_OK_to_continue.'</font></p><br/><br/>
                  <div id="button_ok">
				    <input  id="button_ok2" type="button"  align="middle" name="ok_reg" value="OK" onClick="contant_main(&#34;<?php echo $p_main ?>&#34;)" />
                  </div>
             </div><br>
		     ';	
	  }//if
	  else //we can work with articles: users_status = 1
	  {   //read all articles from articles_table
	     echo
		 '
	        <style>
			   #content_main3 {visibility:  visible;}
    	    </style>;
		 ';
		 
         $rab = table_articles();
		   
      }//else
    }//if
    else  //No registration
    {
      echo '
	         <style>
               #messages {visibility:  visible; }
			   #messages_err {visibility:  visible; }
             </style>;	
	         <div id="messages">
		          <br/>
                  <img src="img/error.png" align="left">
		          <p  align="center"><font color="red">'.$lan_n_o_registred_user.'<br/>
		          '.$lan_Press_OK_to_continue.'</font></p><br/><br/>
                  <div id="button_ok">
				    <input  id="button_ok2" type="button"  align="middle" name="ok_reg" value="OK" onClick="out_articles1()" />
                  </div>
             </div><br>
		     ';	
	
    }//else
  }//if
  else//go_to_registration
  {
    echo '
	         <style>
               #content_main {visibility:  visible; }
             </style>;
	         <div id="content_main_err">
		          <br/>
                  <img src="img/error.png" align="left">
		          <p align="left"><font color="red" font-size="20pt">'.$lan_go_to_registration.'<br/>
		          '.$lan_Press_OK_to_continue.'</font></p><br/><br/>
                  <div id="button_ok">
				    <input  id="button_ok2" type="button"  align="middle" name="ok_reg" value="OK" onClick="contant_main(&#34;<?php echo $p_main ?>&#34;)" />
                  </div>
			 </div>
  	     ';	
  }//else

?>  